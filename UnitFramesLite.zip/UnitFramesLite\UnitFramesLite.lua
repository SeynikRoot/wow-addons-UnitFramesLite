local addonName = ...
local UFL = {}
_G.UnitFramesLite = UFL

local LSM = LibStub and LibStub("LibSharedMedia-3.0", true)

-- Masque (optional): provides button skinning.  Groups are created lazily on
-- first use so the library is not required at load time.
local MSQ         = LibStub and LibStub("Masque", true)
local msqGroups   = {}   -- msqGroups["buff"] / msqGroups["debuff"]

local function GetMSQGroup(prefix)
    if not MSQ then return nil end
    if not msqGroups[prefix] then
        local label = (prefix == "buff") and "Buffs" or "Debuffs"
        msqGroups[prefix] = MSQ:Group("UnitFramesLite", label)
    end
    return msqGroups[prefix]
end

-- CurveConstants.ScaleTo100: when passed to UnitHealthPercent as the third arg,
-- causes it to return a plain (non-secret) number in the 0-100 range.
local SCALE_TO_100 = CurveConstants and CurveConstants.ScaleTo100

local ORB_MASK = "Interface\\CHARACTERFRAME\\TempPortraitAlphaMask"

-- Defaults -------------------------------------------------------------------

local function MakeUnitDefaults(x, y, solidColor, gradStart, gradEnd, orbStart, orbEnd)
    return {
        x = x, y = y,
        font = "Friz Quadrata TT",
        nameAlign = "Left",
        hpColor = {1, 1, 1, 1},
        barBG = {0, 0, 0, 0.35},
        useSolidColor = false,
        solidColor    = solidColor,
        gradientStart = gradStart,
        gradientEnd   = gradEnd,
        gradientDir   = "HORIZONTAL",
        statusbarTexture = "Blizzard",
        enabled       = true,
        reverseFill   = false,
        portrait      = "Portrait Off",  -- legacy, kept for backwards compat
        portraitMode  = "None",           -- "None" | "2D" | "3D" | "Unit Type"
        portraitSide  = "Left",           -- "Left" | "Right"
        portraitClamp = true,             -- clamp to unit frame dimensions
        portraitW     = 35,               -- custom width when not clamped
        portraitH     = 35,               -- custom height when not clamped
        portraitX     = 0,               -- custom X offset when not clamped
        portraitY     = 0,               -- custom Y offset when not clamped
        locked        = false,
        frameWidth    = 160,
        frameHeight   = 35,
        hpBarHeight   = 0,
        showName      = true,
        showHPText    = true,
        showHPPct     = false,
        showLevel     = true,
        showPowerBar  = false,   -- legacy; superseded by orbPowerMode == "Bar"
        powerBarAttach = true,  -- bar mode: attach power bar to bottom of health bar
        showPowerText = false,
        showResources           = true,
        resourcePipWidth        = 18,
        resourcePipHeight       = 6,
        resourcePipGap          = 3,
        resourcePipShape        = "Rectangle",  -- "Rectangle" | "Circle" | "Diamond"
        resourcePipBorderEnabled   = false,
        resourcePipBorderThickness = 1,
        resourcePipBorderColor     = {0, 0, 0, 1},
        resourcePipBgColor         = {0.1, 0.1, 0.1, 0.8},
        resourceX               = 0,
        resourceY               = 0,
        resourceAlpha           = 1.0,
        resourceUseCustomColor  = false,
        resourceColorMode       = "Solid",       -- "Solid" | "Gradient"
        resourceUseSolidColor   = true,          -- kept for back-compat; derived from resourceColorMode
        resourceGradPerPip      = true,
        resourceSolidColor      = {1, 1, 1, 1},
        resourceGradStart       = {1, 1, 1, 1},
        resourceGradEnd         = {0.3, 0.3, 1, 1},
        resourceShowOutCombat   = true,   -- show custom bar out of combat (always shown in combat)
        resourceShowWithTarget  = false,  -- also show custom bar when target selected (any combat state)
        -- Buff display
        buffDisplayMode   = "Icons",   -- "Icons" | "Bars" | "Rings"
        buffIconSize      = 24,
        buffPerRow        = 4,
        buffMaxShown      = 8,
        buffGrowX         = "RIGHT",   -- overridden per-unit below
        buffGrowY         = "DOWN",
        buffXOffset       = 0,
        buffYOffset       = -15,
        buffAnchorToFrame = true,
        buffShowBuffs     = true,
        -- Buff bars mode
        buffBarWidth      = 160,
        buffBarHeight     = 18,
        buffBarX          = 0,
        buffBarY          = 0,
        buffBarShowTimer  = true,
        -- Buff rings mode
        buffRingRadius    = 60,
        buffRingGap       = 8,
        -- Hide auras with total duration > this value (seconds); 0 = disabled
        buffHideOverDuration  = 0,
        -- Timer text (all display modes)
        buffShowTimer     = true,
        buffTimerFont     = nil,           -- nil = default font
        buffTimerFontSize = 10,
        buffTimerColor    = {1, 1, 1, 1},
        -- Debuff display
        debuffDisplayMode = "Icons",   -- "Icons" | "Bars" | "Rings"
        debuffIconSize    = 24,
        debuffPerRow      = 4,
        debuffMaxShown    = 8,
        debuffGrowX       = "LEFT",    -- overridden per-unit below
        debuffGrowY       = "UP",
        debuffXOffset     = 0,
        debuffYOffset     = 0,
        debuffAnchorToFrame = true,
        debuffShowDebuffs = true,
        debuffPlayerOnly  = false,
        debuffCurableOnly = false,
        -- Debuff bars mode
        debuffBarWidth    = 160,
        debuffBarHeight   = 18,
        debuffBarX        = 0,
        debuffBarY        = 0,
        debuffBarShowTimer = true,
        -- Debuff rings mode
        debuffRingRadius  = 60,
        debuffRingGap     = 8,
        -- Hide auras with total duration > this value (seconds); 0 = disabled
        debuffHideOverDuration = 0,
        -- Timer text (all display modes)
        debuffShowTimer   = true,
        debuffTimerFont   = nil,           -- nil = default font
        debuffTimerFontSize = 10,
        debuffTimerColor  = {1, 1, 1, 1},
        buffTooltipEnabled  = true,
        buffTooltipDelay    = 0,
        debuffTooltipEnabled = true,
        debuffTooltipDelay  = 0,
        hpContent = "Cur / Max",  -- "Cur / Max" | "Current" | "Max"
        hpFormat  = "Full",       -- "Full" | "Short" (÷1000k)
        nameTextFontSize = 12, nameTextX = 0, nameTextY = 0,
        nameWrap = false, nameWrapWidth = 80, nameWrapGrow = "DOWN",
        hpTextFontSize   = 11, hpTextX   = 0, hpTextY   = 0,
        levelTextFontSize= 11, levelTextX= 0, levelTextY= 0,
        -- Per-element text colors
        nameColor        = {1, 1, 1, 1},
        hpTextColor      = {1, 1, 1, 1},
        hpPctColor       = {1, 1, 1, 1},
        levelColor       = {1, 1, 1, 1},
        -- Colour by reaction
        nameColorByReaction     = false,
        hpTextColorByReaction   = false,
        hpPctColorByReaction    = false,
        levelColorByReaction    = false,
        reactionUseDefaultColors = true,
        reactionFriendlyColor   = {0, 1, 0, 1},
        reactionNeutralColor    = {1, 1, 0, 1},
        reactionEnemyColor      = {1, 0, 0, 1},
        -- Per-element text alignments
        hpTextAlign      = "Center",
        levelTextAlign   = "Center",
        -- HP Percent (independent of HP text)
        hpPctShowSymbol  = true,
        hpPctFontSize    = 11, hpPctX = 0, hpPctY = -14,
        hpPctAlign       = "Center",
        loadMounted = false, loadInVehicle = false, loadResting  = false,
        loadStealthed = false, loadInCombat = false, loadOutOfCombat = false,
        loadSolo = false, loadInGroup = false, loadInInstance = false,
        syncAlpha = false, keepTextVisible = false,
        alphaAffects = "Everything",
        alphaCombat = 1.0, alphaOutCombat = 1.0,
        fadeNoTarget = false, fadeNoTargetAlpha = 0.4,
        fadeHostileTarget = false,
        -- Elite / rare-elite dragon border
        showEliteBorder     = false,
        eliteBorderTexture  = "Elite",   -- "Elite" | "RareElite" (player/pet: fixed; target/focus: auto)
        eliteBorderReversed = false,     -- flip texture horizontally
        eliteBorderAutoFit  = false,     -- auto-size and position to hug the orb edge
        eliteBorderScale    = 1.0,
        eliteBorderX        = 0,
        eliteBorderY        = 0,
        barBorderEnabled = true, barBorderThickness = 1,
        barBorderColor = {0, 0, 0, 1},
        -- Orb
        orbBgColor        = {0, 0, 0, 0.9},
        sphereMode        = false,
        sphereSize        = 80,
        sphereFillDir     = "VERTICAL",
        orbGradientDir    = "VERTICAL",   -- gradient direction (independent of fill dir)
        orbUseSolidColor  = false,
        orbSolidColor     = orbStart,
        orbGradientStart  = orbStart,
        orbGradientEnd    = orbEnd,
        -- Orb inner border (ring between health orb and power ring)
        showOrbBorder      = false,
        orbBorderThickness = 4,
        orbBorderColor     = {0, 0, 0, 1},
        -- Power ring / bar (orbPowerMode replaces showOrbPower; NOT in defaults so migration can detect nil)
        showOrbPower             = false,  -- kept for migration only
        orbPowerRingThickness    = 8,
        orbPowerRingCCW          = false,
        orbPowerRingUseTypeColor = true,   -- legacy; superseded by orbPowerRingUseFixedColor
        orbPowerRingUseFixedColor = false,  -- false = power type colours; true = fixed colour
        orbPowerRingColor        = {0, 0.5, 1, 1},
        orbPowerRingBgColor      = {0, 0, 0, 0.9},
        -- Power bar (used when orbPowerMode == "Bar")
        orbPowerBarWidth         = 80,
        orbPowerBarHeight        = 12,
        orbPowerBarX             = 0,
        orbPowerBarY             = 0,
        orbPowerBarFillDir       = "HORIZONTAL",
        orbPowerBarColor         = {0, 0.5, 1, 1},
        orbPowerBarBgColor       = {0, 0, 0, 0.9},
        orbPowerBarUseTypeColor  = false,   -- legacy; superseded by orbPowerBarUseFixedColor
        orbPowerBarUseFixedColor = false,   -- false = power type colours; true = fixed colour
        orbPowerBarCentreToScreen = false,
        orbPowerShowOutOfCombat  = true,
    }
end

local function SetTextDefaults(d, nameX, nameY, nameAlign, hpX, hpY, hpAlign, lvlX, lvlY, lvlAlign)
    d.nameTextX = nameX; d.nameTextY = nameY; d.nameAlign = nameAlign
    d.hpTextX   = hpX;   d.hpTextY   = hpY;   d.hpTextAlign = hpAlign
    d.levelTextX= lvlX;  d.levelTextY= lvlY;  d.levelTextAlign = lvlAlign
    return d
end

local defaults = {
    player = SetTextDefaults(MakeUnitDefaults(-175, -75,
        {0.2,0.8,0.2,1}, {0.2,0.8,0.2,1}, {0.1,0.4,0.1,1},
        {0.2,0.5,0.9,1}, {0.05,0.15,0.6,1}),
        0, -118, "Center",
        0, -39, "Center",
        0, 99, "Center"),
    target = SetTextDefaults(MakeUnitDefaults( 175, -75,
        {0.8,0.2,0.2,1}, {0.8,0.2,0.2,1}, {0.4,0.1,0.1,1},
        {0.9,0.3,0.1,1}, {0.5,0.1,0.05,1}),
        0, -118, "Center",
        0, -39, "Center",
        0, 99, "Center"),
    focus  = SetTextDefaults(MakeUnitDefaults(-384, -225,
        {0.6,0.1,0.9,1}, {0.6,0.1,0.9,1}, {0.3,0.05,0.5,1},
        {0.5,0.1,0.9,1}, {0.25,0.05,0.45,1}),
        0, -123, "CENTER",
        0, -39, "CENTER",
        0, 99, "CENTER"),
    pet    = SetTextDefaults(MakeUnitDefaults(-338, -158,
        {0.1,0.7,0.4,1}, {0.1,0.7,0.4,1}, {0.05,0.35,0.2,1},
        {0.1,0.7,0.4,1}, {0.05,0.35,0.2,1}),
        0, -98, "CENTER",
        0, -29, "CENTER",
        0, 72, "CENTER"),
}

-- ── Per-unit default overrides ────────────────────────────────────────────────

-- Player
defaults.player.font                   = "DorisPP"
defaults.player.nameFont               = "Enigmatic"
defaults.player.nameAlign              = "Center"
defaults.player.hpFormat               = "Short"
defaults.player.hpContent              = "Max"
defaults.player.hpBarHeight            = 41
defaults.player.hpTextFontSize         = 10
defaults.player.hpTextY                = -39
defaults.player.hpTextAlign            = "Center"
defaults.player.showHPPct              = true
defaults.player.hpPctFontSize          = 32
defaults.player.hpPctY                 = 0
defaults.player.hpPctShowSymbol        = false
defaults.player.hpPctFont              = "DorisPP"
defaults.player.levelTextFontSize      = 12
defaults.player.levelTextY             = 99
defaults.player.levelColorByReaction   = true
defaults.player.nameTextFontSize       = 11
defaults.player.statusbarTexture       = "BantoBar"
defaults.player.sphereMode             = true
defaults.player.sphereSize             = 100
defaults.player.portraitMode           = "2D"
defaults.player.portraitSide           = "Left"
defaults.player.orbPowerMode           = "Bar"
defaults.player.orbPowerBarWidth       = 260
defaults.player.orbPowerBarHeight      = 5
defaults.player.orbPowerBarY           = -120
defaults.player.orbPowerBarCentreToScreen = true
defaults.player.orbPowerBarUseTypeColor = true
defaults.player.orbPowerBarColor       = {0.294117659330368, 0.658823549747467, 0.6117647290229797, 1}
defaults.player.orbPowerBarBgColor     = {0, 0, 0, 0.4166660606861115}
defaults.player.orbPowerShowOutOfCombat = false
defaults.player.orbPowerRingCCW        = true
defaults.player.orbPowerRingThickness  = 4
defaults.player.orbPowerRingColor      = {0, 0.4000000357627869, 0.7529412508010864, 0.7786459922790527}
defaults.player.orbPowerRingBgColor    = {0.415686309337616, 0.415686309337616, 0.415686309337616, 0.5963543057441711}
defaults.player.showOrbBorder          = true
defaults.player.orbBorderThickness     = 4
defaults.player.showOrbOuterBorder     = true
defaults.player.orbOuterBorderThickness = 3
defaults.player.orbBgColor             = {0.0470588281750679, 0.0784313753247261, 0.0784313753247261, 0.3177079260349274}
defaults.player.orbGradientStart       = {1, 0.2901960909366608, 0, 1}
defaults.player.orbGradientEnd         = {0, 0, 0, 0.8984372019767761}
defaults.player.orbSolidColor          = {0, 0.6392157077789307, 1, 1}
defaults.player.alphaOutCombat         = 0.5
defaults.player.alphaCombat            = 1
defaults.player.fadeNoTarget           = true
defaults.player.fadeNoTargetAlpha      = 0
defaults.player.fadeHostileTarget      = true
defaults.player.powerBarAttach         = false
defaults.player.showPowerBar           = true
defaults.player.showOrbPower           = true
defaults.player.eliteBorderReversed    = true
defaults.player.eliteBorderAutoFit     = true
defaults.player.eliteBorderScale       = 1.25
defaults.player.eliteBorderX           = -3
defaults.player.eliteBorderTexture     = "RareElite"
defaults.player.buffGrowX              = "LEFT"
defaults.player.buffGrowY              = "DOWN"
defaults.player.buffXOffset            = 63
defaults.player.buffYOffset            = -30
defaults.player.buffIconSize           = 35
defaults.player.debuffGrowX            = "LEFT"
defaults.player.debuffGrowY            = "UP"
defaults.player.debuffXOffset          = 63
defaults.player.debuffYOffset          = 20
defaults.player.debuffIconSize         = 35
defaults.player.debuffHideOverDuration = 30
defaults.player.buffHideOverDuration   = 30
defaults.player.buffTimerFontSize      = 17
defaults.player.buffShowTimer          = false
defaults.player.debuffShowTimer        = false
defaults.player.resourcePipShape       = "Circle"
defaults.player.resourcePipWidth       = 17
defaults.player.resourcePipHeight      = 17
defaults.player.resourcePipGap         = 10
defaults.player.resourceY              = -100
defaults.player.resourceShowOutCombat  = false
defaults.player.resourceShowWithTarget = true
defaults.player.resourceUseCustomColor = true
defaults.player.resourceColorMode      = "Horizontal Gradient"
defaults.player.resourceUseSolidColor  = false
defaults.player.resourceGradStart      = {0.6823529601097107, 0, 0.1803921610116959, 1}
defaults.player.resourceGradEnd        = {0.9529412388801575, 1, 0, 1}
defaults.player.resourcePipBorderEnabled   = true
defaults.player.resourcePipBorderThickness = 1
defaults.player.resourcePipBorderColor = {0.04313725605607033, 0.04313725605607033, 0.04313725605607033, 0.7708333134651184}
defaults.player.resourcePipBgColor     = {0.1607843190431595, 0.1607843190431595, 0.1607843190431595, 0.3541665375232697}
defaults.player.hpBarBgColor           = {0, 0, 0, 0}
defaults.player.hpDisplayMode         = "percent"

-- Target
defaults.target.font                   = "DorisPP"
defaults.target.nameFont               = "Enigmatic"
defaults.target.nameAlign              = "Center"
defaults.target.hpFormat               = "Short"
defaults.target.hpContent              = "Max"
defaults.target.hpBarHeight            = 41
defaults.target.hpTextFontSize         = 10
defaults.target.hpTextY                = -39
defaults.target.hpTextAlign            = "Center"
defaults.target.showHPPct              = true
defaults.target.hpPctFontSize          = 32
defaults.target.hpPctY                 = 0
defaults.target.hpPctShowSymbol        = false
defaults.target.hpPctFont              = "DorisPP"
defaults.target.levelTextFontSize      = 12
defaults.target.levelTextY             = 99
defaults.target.levelColorByReaction   = true
defaults.target.nameTextFontSize       = 11
defaults.target.nameWrap               = true
defaults.target.nameWrapWidth          = 120
defaults.target.statusbarTexture       = "BantoBar"
defaults.target.sphereMode             = true
defaults.target.sphereSize             = 100
defaults.target.portraitMode           = "2D"
defaults.target.portraitSide           = "Right"
defaults.target.orbPowerMode           = "Bar"
defaults.target.orbPowerBarWidth       = 260
defaults.target.orbPowerBarHeight      = 5
defaults.target.orbPowerBarY           = -120
defaults.target.orbPowerBarCentreToScreen = true
defaults.target.orbPowerBarUseTypeColor = true
defaults.target.orbPowerBarColor       = {0.294117659330368, 0.658823549747467, 0.6117647290229797, 1}
defaults.target.orbPowerBarBgColor     = {0, 0, 0, 0.4166660606861115}
defaults.target.orbPowerShowOutOfCombat = false
defaults.target.orbPowerRingCCW        = true
defaults.target.orbPowerRingThickness  = 4
defaults.target.orbPowerRingColor      = {0, 0.4000000357627869, 0.7529412508010864, 0.7786459922790527}
defaults.target.orbPowerRingBgColor    = {0.415686309337616, 0.415686309337616, 0.415686309337616, 0.5963543057441711}
defaults.target.showOrbBorder          = true
defaults.target.orbBorderThickness     = 4
defaults.target.showOrbOuterBorder     = true
defaults.target.orbOuterBorderThickness = 3
defaults.target.orbBgColor             = {0.0470588281750679, 0.0784313753247261, 0.0784313753247261, 0.3177079260349274}
defaults.target.orbGradientStart       = {1, 0.2901960909366608, 0, 1}
defaults.target.orbGradientEnd         = {0, 0, 0, 0.8984372019767761}
defaults.target.orbSolidColor          = {0, 0.6392157077789307, 1, 1}
defaults.target.alphaOutCombat         = 0.5
defaults.target.alphaCombat            = 1
defaults.target.fadeNoTarget           = false
defaults.target.fadeNoTargetAlpha      = 0
defaults.target.fadeHostileTarget      = true
defaults.target.powerBarAttach         = false
defaults.target.showPowerBar           = true
defaults.target.showOrbPower           = true
defaults.target.nameColorByReaction    = true
defaults.target.showEliteBorder        = true
defaults.target.eliteBorderTexture     = "RareElite"
defaults.target.eliteBorderAutoFit     = true
defaults.target.eliteBorderScale       = 1.25
defaults.target.eliteBorderX           = 7
defaults.target.eliteBorderY           = 1
defaults.target.buffGrowX              = "RIGHT"
defaults.target.buffGrowY              = "DOWN"
defaults.target.buffXOffset            = 63
defaults.target.buffYOffset            = -30
defaults.target.buffIconSize           = 35
defaults.target.debuffGrowX            = "RIGHT"
defaults.target.debuffGrowY            = "UP"
defaults.target.debuffXOffset          = 63
defaults.target.debuffYOffset          = 20
defaults.target.debuffIconSize         = 35
defaults.target.debuffHideOverDuration = 30
defaults.target.buffHideOverDuration   = 30
defaults.target.buffTimerFontSize      = 17
defaults.target.buffShowTimer          = false
defaults.target.debuffShowTimer        = false
defaults.target.resourcePipShape       = "Circle"
defaults.target.resourcePipWidth       = 19
defaults.target.resourcePipHeight      = 19
defaults.target.resourcePipGap         = 5
defaults.target.resourceY              = -100
defaults.target.resourceShowOutCombat  = true
defaults.target.resourceShowWithTarget = false
defaults.target.resourceUseCustomColor = false
defaults.target.resourceGradPerPip     = true
defaults.target.resourcePipBorderEnabled   = true
defaults.target.resourcePipBorderThickness = 2
defaults.target.resourcePipBorderColor = {0, 0, 0, 1}
defaults.target.resourcePipBgColor     = {0.1, 0.1, 0.1, 0.8}
defaults.target.hpBarBgColor           = {0, 0, 0, 0}
defaults.target.hpDisplayMode          = "percent"
defaults.target.levelColor             = {1, 0.9921569228172302, 0.9803922176361084, 1}

-- Focus
defaults.focus.font                    = "DorisPP"
defaults.focus.nameFont                = "DorisPP"
defaults.focus.nameAlign               = "CENTER"
defaults.focus.hpFormat                = "Short"
defaults.focus.hpContent               = "Max"
defaults.focus.hpBarHeight             = 41
defaults.focus.hpTextFontSize          = 10
defaults.focus.hpTextY                 = -39
defaults.focus.hpTextAlign             = "CENTER"
defaults.focus.showHPPct               = true
defaults.focus.hpPctFontSize           = 32
defaults.focus.hpPctY                  = 0
defaults.focus.hpPctShowSymbol         = false
defaults.focus.hpPctFont               = "DorisPP"
defaults.focus.levelTextFontSize       = 10
defaults.focus.levelTextY              = 99
defaults.focus.nameTextFontSize        = 10
defaults.focus.nameTextY               = -123
defaults.focus.statusbarTexture        = "BantoBar"
defaults.focus.sphereMode              = true
defaults.focus.sphereSize              = 100
defaults.focus.portraitMode            = "2D"
defaults.focus.portraitSide            = "Left"
defaults.focus.orbPowerMode            = "Bar"
defaults.focus.orbPowerBarWidth        = 248
defaults.focus.orbPowerBarHeight       = 4
defaults.focus.orbPowerBarX            = 220
defaults.focus.orbPowerBarY            = 39
defaults.focus.orbPowerBarUseTypeColor = true
defaults.focus.orbPowerBarColor        = {0.294117659330368, 0.658823549747467, 0.6117647290229797, 1}
defaults.focus.orbPowerBarBgColor      = {0, 0, 0, 0.4166660606861115}
defaults.focus.orbPowerShowOutOfCombat = false
defaults.focus.orbPowerRingCCW         = true
defaults.focus.orbPowerRingThickness   = 4
defaults.focus.orbPowerRingColor       = {0, 0.4000000357627869, 0.7529412508010864, 0.7786459922790527}
defaults.focus.orbPowerRingBgColor     = {0.415686309337616, 0.415686309337616, 0.415686309337616, 0.5963543057441711}
defaults.focus.showOrbBorder           = false
defaults.focus.orbBorderColor          = {0, 0, 0, 0.4557291865348816}
defaults.focus.showOrbOuterBorder      = true
defaults.focus.orbOuterBorderThickness = 3
defaults.focus.orbBgColor              = {0.0470588281750679, 0.0784313753247261, 0.0784313753247261, 0.3177079260349274}
defaults.focus.orbGradientStart        = {0, 0, 0, 1}
defaults.focus.orbGradientEnd          = {0.7686275243759155, 0.4078431725502014, 1, 0.8984372019767761}
defaults.focus.orbSolidColor           = {1, 0.5490196347236633, 0.7529412508010864, 1}
defaults.focus.alphaOutCombat          = 0.5
defaults.focus.alphaCombat             = 1
defaults.focus.fadeNoTarget            = true
defaults.focus.fadeNoTargetAlpha       = 0
defaults.focus.fadeHostileTarget       = false
defaults.focus.powerBarAttach          = true
defaults.focus.showPowerBar            = true
defaults.focus.showOrbPower            = true
defaults.focus.buffGrowX               = "LEFT"
defaults.focus.buffGrowY               = "DOWN"
defaults.focus.buffXOffset             = 45
defaults.focus.buffYOffset             = -18
defaults.focus.debuffGrowX             = "LEFT"
defaults.focus.debuffGrowY             = "UP"
defaults.focus.debuffHideOverDuration  = 60
defaults.focus.buffHideOverDuration    = 60
defaults.focus.resourcePipShape        = "Circle"
defaults.focus.resourcePipWidth        = 19
defaults.focus.resourcePipHeight       = 19
defaults.focus.resourcePipGap          = 5
defaults.focus.resourceY               = -100
defaults.focus.resourceShowOutCombat   = true
defaults.focus.resourceShowWithTarget  = false
defaults.focus.resourceUseCustomColor  = false
defaults.focus.resourceColorMode       = "Horizontal Gradient"
defaults.focus.resourceGradPerPip      = true
defaults.focus.resourceGradStart       = {1, 0.9411765336990356, 0.8509804606437683, 1}
defaults.focus.resourceGradEnd         = {1, 0.003921568859368563, 0.2000000178813934, 1}
defaults.focus.resourcePipBorderEnabled   = true
defaults.focus.resourcePipBorderThickness = 2
defaults.focus.resourcePipBorderColor  = {0, 0, 0, 1}
defaults.focus.resourcePipBgColor      = {0.1, 0.1, 0.1, 0.8}
defaults.focus.hpBarBgColor            = {0, 0, 0, 0}
defaults.focus.hpDisplayMode           = "percent"
defaults.focus.showResources           = false

-- Pet
defaults.pet.font                      = "DorisPP"
defaults.pet.nameFont                  = "DorisPP"
defaults.pet.nameAlign                 = "CENTER"
defaults.pet.hpFormat                  = "Short"
defaults.pet.hpContent                 = "Max"
defaults.pet.hpBarHeight               = 41
defaults.pet.hpTextFontSize            = 10
defaults.pet.hpTextY                   = -29
defaults.pet.hpTextAlign               = "CENTER"
defaults.pet.showHPPct                 = true
defaults.pet.hpPctFontSize             = 32
defaults.pet.hpPctY                    = 0
defaults.pet.hpPctShowSymbol           = false
defaults.pet.hpPctFont                 = "DorisPP"
defaults.pet.levelTextFontSize         = 10
defaults.pet.levelTextY                = 72
defaults.pet.nameTextFontSize          = 10
defaults.pet.statusbarTexture          = "BantoBar"
defaults.pet.sphereMode                = true
defaults.pet.sphereSize                = 74
defaults.pet.portraitMode              = "2D"
defaults.pet.portraitSide              = "Left"
defaults.pet.orbPowerMode              = "Bar"
defaults.pet.orbPowerBarWidth          = 248
defaults.pet.orbPowerBarHeight         = 4
defaults.pet.orbPowerBarX              = 220
defaults.pet.orbPowerBarY              = 39
defaults.pet.orbPowerBarUseTypeColor   = true
defaults.pet.orbPowerBarColor          = {0.294117659330368, 0.658823549747467, 0.6117647290229797, 1}
defaults.pet.orbPowerBarBgColor        = {0, 0, 0, 0.4166660606861115}
defaults.pet.orbPowerShowOutOfCombat   = false
defaults.pet.orbPowerRingCCW           = true
defaults.pet.orbPowerRingThickness     = 4
defaults.pet.orbPowerRingColor         = {0, 0.4000000357627869, 0.7529412508010864, 0.7786459922790527}
defaults.pet.orbPowerRingBgColor       = {0.415686309337616, 0.415686309337616, 0.415686309337616, 0.5963543057441711}
defaults.pet.showOrbBorder             = false
defaults.pet.orbBorderColor            = {0, 0, 0, 0.4557291865348816}
defaults.pet.showOrbOuterBorder        = true
defaults.pet.orbOuterBorderThickness   = 3
defaults.pet.orbBgColor                = {0.0470588281750679, 0.0784313753247261, 0.0784313753247261, 0.3177079260349274}
defaults.pet.orbGradientStart          = {0, 0, 0, 1}
defaults.pet.orbGradientEnd            = {0.7686275243759155, 0.4078431725502014, 1, 0.8984372019767761}
defaults.pet.orbSolidColor             = {1, 0.5490196347236633, 0.7529412508010864, 1}
defaults.pet.alphaOutCombat            = 0.5
defaults.pet.alphaCombat               = 1
defaults.pet.fadeNoTarget              = true
defaults.pet.fadeNoTargetAlpha         = 0
defaults.pet.fadeHostileTarget         = false
defaults.pet.powerBarAttach            = true
defaults.pet.showPowerBar              = true
defaults.pet.showOrbPower              = true
defaults.pet.buffGrowX                 = "LEFT"
defaults.pet.buffGrowY                 = "DOWN"
defaults.pet.buffXOffset               = 45
defaults.pet.buffYOffset               = -18
defaults.pet.buffShowBuffs             = false
defaults.pet.debuffGrowX               = "LEFT"
defaults.pet.debuffGrowY               = "UP"
defaults.pet.debuffHideOverDuration    = 60
defaults.pet.buffHideOverDuration      = 60
defaults.pet.resourcePipShape          = "Circle"
defaults.pet.resourcePipWidth          = 19
defaults.pet.resourcePipHeight         = 19
defaults.pet.resourcePipGap            = 5
defaults.pet.resourceY                 = -100
defaults.pet.resourceShowOutCombat     = true
defaults.pet.resourceShowWithTarget    = false
defaults.pet.resourceUseCustomColor    = false
defaults.pet.resourceColorMode         = "Horizontal Gradient"
defaults.pet.resourceGradPerPip        = true
defaults.pet.resourceGradStart         = {1, 0.9411765336990356, 0.8509804606437683, 1}
defaults.pet.resourceGradEnd           = {1, 0.003921568859368563, 0.2000000178813934, 1}
defaults.pet.resourcePipBorderEnabled  = true
defaults.pet.resourcePipBorderThickness = 2
defaults.pet.resourcePipBorderColor    = {0, 0, 0, 1}
defaults.pet.resourcePipBgColor        = {0.1, 0.1, 0.1, 0.8}
defaults.pet.hpBarBgColor              = {0, 0, 0, 0}
defaults.pet.hpDisplayMode             = "percent"
defaults.pet.showResources             = false

local frames = {}
local auraFrames = {}  -- forward-declared; populated by GetAuraData below

local function CopyDefaults(src, dest)
    if type(dest) ~= "table" then dest = {} end
    for k, v in pairs(src) do
        if type(v) == "table" then
            dest[k] = CopyDefaults(v, dest[k])
        elseif dest[k] == nil then
            dest[k] = v
        end
    end
    return dest
end


-- ── Donut ring textures ───────────────────────────────────────────────────────
-- Pre-built TGA ring textures with real alpha-channel holes.  Used for aura
-- rings and the orb inner border so the background shows through the centre.
-- Native texture size assumed for all Ring_Npx textures (square).
local RING_TEX_NATIVE = 128
-- Desired visual band thickness in screen pixels.
local RING_BAND_PX = 12
-- {nativeBandWidth, addonRelativePath}
local RING_TEXTURES = {
    { 10, "Interface\\AddOns\\UnitFramesLite\\Textures\\Ring_10px" },
    { 20, "Interface\\AddOns\\UnitFramesLite\\Textures\\Ring_20px" },
    { 30, "Interface\\AddOns\\UnitFramesLite\\Textures\\Ring_30px" },
    { 40, "Interface\\AddOns\\UnitFramesLite\\Textures\\Ring_40px" },
}
local function ChooseRingTexture(outerDiameter)
    local bestPath, bestDiff = RING_TEXTURES[1][2], math.huge
    for _, entry in ipairs(RING_TEXTURES) do
        local nativeBand, path = entry[1], entry[2]
        local diff = math.abs(nativeBand * (outerDiameter / RING_TEX_NATIVE) - RING_BAND_PX)
        if diff < bestDiff then bestDiff = diff; bestPath = path end
    end
    return bestPath
end

local function GetDB(unit)
    UnitFramesLiteDB = UnitFramesLiteDB or {}
    local def = defaults[unit] or defaults.player
    UnitFramesLiteDB[unit] = CopyDefaults(def, UnitFramesLiteDB[unit] or {})
    return UnitFramesLiteDB[unit]
end

-- Visibility -----------------------------------------------------------------

local function CheckLoadConditions(unit)
    local db = GetDB(unit)
    local anySet = db.loadMounted or db.loadInVehicle or db.loadResting or
                   db.loadStealthed or db.loadInCombat or db.loadOutOfCombat or
                   db.loadSolo or db.loadInGroup or db.loadInInstance
    if not anySet then return true end
    if db.loadMounted     and IsMounted()                       then return true end
    if db.loadInVehicle   and UnitInVehicle("player")           then return true end
    if db.loadResting     and IsResting()                       then return true end
    if db.loadStealthed   and IsStealthed()                     then return true end
    if db.loadInCombat    and UnitAffectingCombat("player")     then return true end
    if db.loadOutOfCombat and not UnitAffectingCombat("player") then return true end
    if db.loadSolo        and not IsInGroup()                   then return true end
    if db.loadInGroup     and IsInGroup()                       then return true end
    if db.loadInInstance  and IsInInstance()                    then return true end
    return false
end

function UnitFramesLite_UpdateVisibility(unit)
    local frame = frames[unit]
    if not frame then return end
    local db = GetDB(unit)
    if not db.enabled then frame:Hide(); return end
    -- Hide unit-specific frames when unit doesn't exist
    if unit ~= "player" and not UnitExists(unit) then frame:Hide(); return end
    frame:SetShown(CheckLoadConditions(unit))
end

-- Returns false when the unit has no meaningful power resource to display.
-- WoW 12.0 secret numbers make UnitPowerMax unsafe to compare in Lua.
-- We instead check whether the unit is a player or player-controlled unit
-- (pets, player-controlled vehicles) — only these reliably have a power bar.
-- Non-player enemies and dummies are excluded even if WoW assigns them a
-- secret non-zero mana value.
local function UnitHasPower(unit)
    if not UnitExists(unit) then return false end
    return UnitIsPlayer(unit) or UnitPlayerControlled(unit) or false
end

-- Alpha ----------------------------------------------------------------------

function UnitFramesLite_UpdateAlpha(unit)
    local frame = frames[unit]
    if not frame then return end
    local db = GetDB(unit)

    local alphaDB  = (db.syncAlpha) and GetDB("player") or db
    local inCombat = UnitAffectingCombat("player")
    local alpha    = inCombat and (alphaDB.alphaCombat or 1) or (alphaDB.alphaOutCombat or 1)

    local hasTarget = UnitExists("target")
    if db.fadeNoTarget and not hasTarget and not inCombat then
        alpha = db.fadeNoTargetAlpha or 0.4
    elseif db.fadeHostileTarget and not inCombat then
        -- Treat a non-hostile (or no) target the same as no target
        local isHostile = hasTarget and (UnitReaction("target", "player") or 4) <= 3
        if not isHostile then
            alpha = db.fadeNoTargetAlpha or 0.4
        end
    end


    local textAlpha = db.keepTextVisible and 1 or alpha
    local affects   = alphaDB.alphaAffects or "Everything"

    if affects == "Foreground" then
        frame.hp:SetAlpha(alpha)
        if frame.power      then frame.power:SetAlpha(alpha) end
        frame.bg:SetAlpha(1)
        if frame.orbFill    then frame.orbFill:SetAlpha(alpha) end
        if frame.orbFill2   then frame.orbFill2:SetAlpha(alpha) end
    elseif affects == "Background" then
        frame.bg:SetAlpha(alpha)
        frame.hp:SetAlpha(1)
        if frame.power      then frame.power:SetAlpha(1) end
        if frame.orbFill    then frame.orbFill:SetAlpha(1) end
        if frame.orbFill2   then frame.orbFill2:SetAlpha(1) end
        if frame.orbBg      then frame.orbBg:SetAlpha(alpha) end
    else
        frame.hp:SetAlpha(alpha)
        if frame.power      then frame.power:SetAlpha(alpha) end
        frame.bg:SetAlpha(alpha)
        if frame.orbFill    then frame.orbFill:SetAlpha(alpha) end
        if frame.orbFill2   then frame.orbFill2:SetAlpha(alpha) end
        if frame.orbBg      then frame.orbBg:SetAlpha(alpha) end
    end

    local showPowerOOC = db.orbPowerShowOutOfCombat ~= false
    local hasPower     = UnitHasPower(unit)
    local powerAlpha   = hasPower and ((inCombat or showPowerOOC) and alpha or 0) or 0
    if frame.powerRingFrame then frame.powerRingFrame:SetAlpha(powerAlpha) end
    if frame.orbPowerBar    then frame.orbPowerBar:SetAlpha(powerAlpha)    end
    if frame.orbBorderFrame  then frame.orbBorderFrame:SetAlpha(alpha)  end
    if frame.borderFrame     then frame.borderFrame:SetAlpha(alpha)     end
    if frame.eliteBorderFrame then frame.eliteBorderFrame:SetAlpha(alpha) end

    -- Set alpha on the overlay frame AND directly on each FontString.
    -- The HIGH strata of textOverlay can cause alpha inheritance issues in WoW,
    -- so we belt-and-suspenders by setting both the frame and each text element.
    if frame.textOverlay then frame.textOverlay:SetAlpha(textAlpha) end
    if frame.nameText    then frame.nameText:SetAlpha(textAlpha)    end
    if frame.hpText      then frame.hpText:SetAlpha(textAlpha)      end
    if frame.hpPctText   then frame.hpPctText:SetAlpha(textAlpha)   end
    if frame.levelText   then frame.levelText:SetAlpha(textAlpha)   end

    -- Portrait and aura containers are parented to UIParent so must be alpha'd explicitly
    if frame.portraitFrame and frame.portraitFrame:IsShown() then
        frame.portraitFrame:SetAlpha(alpha)
    end
    local auraData = auraFrames[unit]
    if auraData then
        if auraData.buff   and auraData.buff.container   then auraData.buff.container:SetAlpha(alpha)   end
        if auraData.debuff and auraData.debuff.container then auraData.debuff.container:SetAlpha(alpha) end
    end

    -- Propagate to any other units that are syncing their alpha from this unit
    if unit == "player" then
        for otherUnit, _ in pairs(frames) do
            if otherUnit ~= "player" and GetDB(otherUnit).syncAlpha then
                UnitFramesLite_UpdateAlpha(otherUnit)
            end
        end
    end
end

-- Elite / rare-elite dragon border -------------------------------------------
-- Custom textures in the addon folder.
-- Elite.tga     → elite and worldboss units (or fixed choice for player/pet)
-- RareElite.tga → rare-elite and rare units (or fixed choice for player/pet)

local ELITE_TEX_ELITE     = "Interface\\AddOns\\UnitFramesLite\\Elite"
local ELITE_TEX_RAREELITE = "Interface\\AddOns\\UnitFramesLite\\RareElite"

-- Classification → texture for target/focus (auto mode).
local ELITE_CLASS_TEX = {
    worldboss = ELITE_TEX_ELITE,
    elite     = ELITE_TEX_ELITE,
    rareelite = ELITE_TEX_RAREELITE,
    rare      = ELITE_TEX_RAREELITE,
}

function UnitFramesLite_UpdateEliteBorder(unit)
    local frame = frames[unit]
    if not frame or not frame.eliteBorderFrame then return end

    local db = GetDB(unit)

    if not db.showEliteBorder then
        frame.eliteBorderFrame:Hide()
        return
    end

    -- Player/pet: always show the configured texture (no classification check).
    -- Target/focus: auto-select texture from unit classification; hide if not elite.
    local texPath
    if unit == "player" or unit == "pet" then
        texPath = (db.eliteBorderTexture == "RareElite") and ELITE_TEX_RAREELITE or ELITE_TEX_ELITE
    else
        if not UnitExists(unit) then
            frame.eliteBorderFrame:Hide()
            return
        end
        texPath = ELITE_CLASS_TEX[UnitClassification(unit)]
    end

    if not texPath then
        frame.eliteBorderFrame:Hide()
        return
    end

    frame.eliteBorderTex:SetTexture(texPath)

    -- Horizontal flip for reversed orientation.
    -- SetTexCoord(ULx,ULy, LLx,LLy, URx,URy, LRx,LRy)
    if db.eliteBorderReversed then
        frame.eliteBorderTex:SetTexCoord(1, 0, 1, 1, 0, 0, 0, 1)  -- mirrored horizontally
    else
        frame.eliteBorderTex:SetTexCoord(0, 0, 0, 1, 1, 0, 1, 1)  -- normal
    end

    -- Size and position the dragon border frame.
    --
    -- Auto-fit (orb mode only): scales the frame to match the orb diameter and
    -- centres it so the dragon's arc aligns with the orb edge.
    --
    -- Calibrated from observed good fit: at sphereSize=80, sz=100 (scale×1.25),
    -- offX=-3 (right/normal) places the dragon arc flush with the orb.
    -- The reversed image mirrors horizontally, so the offX sign flips.
    -- Both orientations sit on the right side of the orb; the flip just changes
    -- which way the dragon faces (head up vs tail up).
    local ebf = frame.eliteBorderFrame
    local sz, offX, offY

    if db.eliteBorderAutoFit and db.sphereMode then
        local orbDiam = math.max(20, db.sphereSize or 80)
        sz   = orbDiam * 1.25                           -- empirically calibrated scale
        offX = (db.eliteBorderReversed and 1 or -1) * orbDiam * 0.0375
        offY = 0
        -- User fine-tune offsets applied on top
        offX = offX + (db.eliteBorderX or 0)
        offY = offY + (db.eliteBorderY or 0)
    else
        -- Manual mode: scale relative to the unit frame size
        local baseSize
        if db.sphereMode then
            baseSize = math.max(20, db.sphereSize or 80)
        else
            baseSize = math.max(db.frameWidth or 160, db.frameHeight or 35) * 1.4
        end
        sz   = math.max(20, baseSize * (db.eliteBorderScale or 1.0))
        offX = db.eliteBorderX or 0
        offY = db.eliteBorderY or 0
    end

    ebf:SetSize(sz, sz)
    ebf:ClearAllPoints()
    ebf:SetPoint("CENTER", frame, "CENTER", offX, offY)
    ebf:Show()
end

-- Health text ----------------------------------------------------------------
-- content: "Cur / Max" | "Current" | "Max"
-- format:  "Full" (raw integers) | "Short" (÷1000, "k" suffix)
--
-- pcall guards ALL arithmetic/format on secret health values (WoW 12.0+).
-- string.format("%d", secretNum) is safe and returns a secret string.
-- secretNum / 1000 is arithmetic and throws — caught by pcall, returns nil.
-- NEVER compare the return value to another string — only compare to nil.
local DEAD_COLOR = {0.55, 0.55, 0.55, 1}

local function GetHealthText(hp, maxhp, isDead, content, format)
    if isDead then return "Dead" end
    local isShort = (format == "Short")
    local ok, text = pcall(function()
        if content == "Current" then
            if isShort then return string.format("%.0fk", hp / 1000)
            else             return string.format("%d", hp) end
        elseif content == "Max" then
            if isShort then return string.format("%.0fk", maxhp / 1000)
            else             return string.format("%d", maxhp) end
        else  -- "Cur / Max" (default)
            if isShort then return string.format("%.0fk / %.0fk", hp / 1000, maxhp / 1000)
            else             return string.format("%d / %d", hp, maxhp) end
        end
    end)
    return ok and text or nil
end

-- Returns true if unit HP is at or below threshold (0-100), false otherwise.

-- Returns a formatted HP% string by building it entirely inside pcall.
-- string.format receives the result of pcall, which is always a plain string.
local function GetHPPercentText(isDead, showSymbol, unit)
    if isDead then return nil end
    local sym = (showSymbol ~= false) and "%" or ""
    local ok, str = pcall(function()
        local pct = UnitHealthPercent(unit, true, CurveConstants and CurveConstants.ScaleTo100)
        return string.format("%d", pct) .. sym
    end)
    return ok and str or nil
end

-- Font resolution helper -----------------------------------------------------
-- Resolves a per-element font key (e.g. "nameFont") with fallback to db.font.

local function ResolveFont(db, elemKey)
    local name = db[elemKey] or db.font
    if LSM and name then return LSM:Fetch("font", name) or STANDARD_TEXT_FONT end
    return STANDARD_TEXT_FONT
end

-- Reaction colour helper -----------------------------------------------------
-- Returns the appropriate reaction colour table for `unit` if colorByReaction
-- is enabled, otherwise returns nil (caller falls back to the static colour).

local REACTION_FRIENDLY_DEFAULT = {0, 1, 0, 1}
local REACTION_NEUTRAL_DEFAULT  = {1, 1, 0, 1}
local REACTION_ENEMY_DEFAULT    = {1, 0, 0, 1}

local function GetReactionColor(unit, db)
    if unit == "player" then return nil end  -- player is always friendly to themselves
    local reaction = UnitReaction(unit, "player")
    if not reaction then return nil end
    local useDefault = db.reactionUseDefaultColors ~= false
    if reaction >= 5 then
        return useDefault and REACTION_FRIENDLY_DEFAULT or (db.reactionFriendlyColor or REACTION_FRIENDLY_DEFAULT)
    elseif reaction == 4 then
        return useDefault and REACTION_NEUTRAL_DEFAULT  or (db.reactionNeutralColor  or REACTION_NEUTRAL_DEFAULT)
    else
        return useDefault and REACTION_ENEMY_DEFAULT    or (db.reactionEnemyColor    or REACTION_ENEMY_DEFAULT)
    end
end

-- Text element helper --------------------------------------------------------

local function ApplyTextElement(fs, anchorFrame, fontPath, fontSize, color, x, y, justifyH)
    if not fs then return end
    fs:SetFont(fontPath, fontSize or 12, "OUTLINE")
    if color then fs:SetTextColor(color[1], color[2], color[3], color[4]) end
    fs:ClearAllPoints()
    fs:SetPoint("CENTER", anchorFrame, "CENTER", x or 0, y or 0)
    fs:SetWidth(anchorFrame:GetWidth() - 4)
    fs:SetJustifyH(string.upper(justifyH or "CENTER"))
end

-- Applies name text positioning, wrap, and width.
-- In wrap mode the anchor point shifts to TOP/BOTTOM so rows grow in the
-- chosen direction; the text width drives where words break.
local function ApplyNameText(fs, anchorFrame, db, x, y)
    if not fs then return end
    local wrap     = db.nameWrap or false
    local wrapW    = db.nameWrapWidth or 80
    local grow     = db.nameWrapGrow or "DOWN"
    fs:SetWordWrap(wrap)
    if wrap then
        fs:SetWidth(wrapW)
        fs:ClearAllPoints()
        if grow == "UP" then
            fs:SetPoint("BOTTOM", anchorFrame, "CENTER", x, y)
        else
            fs:SetPoint("TOP", anchorFrame, "CENTER", x, y)
        end
    else
        fs:SetWidth(wrapW > 0 and wrapW or (anchorFrame:GetWidth() - 4))
        fs:ClearAllPoints()
        fs:SetPoint("CENTER", anchorFrame, "CENTER", x, y)
    end
    fs:SetJustifyH(string.upper(db.nameAlign or "CENTER"))
end

-- Orb fill helper ------------------------------------------------------------
-- reversedGrad: used for the lower half of CENTRE mode — swaps gradient start/end
-- vertically so the orb centre is always gradientStart (bright) with no seam.

local function ApplyOrbFill(bar, db, circMask, reversedGrad, unit)
    bar:SetStatusBarTexture("Interface\\Buttons\\WHITE8X8")
    if db.orbUseSolidColor then
        local c = db.orbSolidColor or {0.1, 0.3, 0.9, 1}
        bar:SetStatusBarColor(c[1], c[2], c[3], c[4])
    else
        bar:SetStatusBarColor(1, 1, 1, 1)
        local gs   = db.orbGradientStart or {0.2, 0.5, 0.9, 1}
        local ge   = db.orbGradientEnd   or {0.05, 0.15, 0.6, 1}
        local gDir = db.orbGradientDir   or "VERTICAL"
        -- CENTRE gradient uses VERTICAL internally; the two-half split in
        -- UpdateFrame creates the radial effect. reversedGrad flips the lower half
        -- so both halves are bright at the orb centre with no visible seam.
        local effectiveDir = (gDir == "CENTRE") and "VERTICAL" or gDir
        local sbTex = bar:GetStatusBarTexture()
        if sbTex then
            if reversedGrad and effectiveDir == "VERTICAL" then
                sbTex:SetGradient(effectiveDir,
                    CreateColor(ge[1], ge[2], ge[3], ge[4]),
                    CreateColor(gs[1], gs[2], gs[3], gs[4]))
            else
                sbTex:SetGradient(effectiveDir,
                    CreateColor(gs[1], gs[2], gs[3], gs[4]),
                    CreateColor(ge[1], ge[2], ge[3], ge[4]))
            end
        end
    end
    local sbTex = bar:GetStatusBarTexture()
    if sbTex and circMask then sbTex:AddMaskTexture(circMask) end
end

-- Power ring fill helper -----------------------------------------------------

-- Ordered list of primary power types used for the per-type colour UI.
-- Each entry: { key = Enum.PowerType.X, label = "Name", dbKey = "ptc_<name>" }
local POWER_TYPE_LIST = {}
local POWER_TYPE_DEFAULTS = {}  -- dbKey → {r,g,b,1}

local function RegPT(enumKey, label, r, g, b)
    if enumKey == nil then return end
    local dbKey = "ptc_" .. label:lower():gsub(" ", "_")
    POWER_TYPE_LIST[#POWER_TYPE_LIST + 1] = { enumKey = enumKey, label = label, dbKey = dbKey }
    POWER_TYPE_DEFAULTS[dbKey] = {r, g, b, 1}
end
RegPT(Enum.PowerType.Mana,        "Mana",        0.00, 0.00, 1.00)
RegPT(Enum.PowerType.Rage,        "Rage",        1.00, 0.00, 0.00)
RegPT(Enum.PowerType.Focus,       "Focus",       1.00, 0.50, 0.25)
RegPT(Enum.PowerType.Energy,      "Energy",      1.00, 1.00, 0.00)
RegPT(Enum.PowerType.RunicPower,  "Runic Power", 0.00, 0.82, 1.00)
RegPT(Enum.PowerType.Fury,        "Fury",        0.79, 0.26, 0.99)
RegPT(Enum.PowerType.Pain,        "Pain",        1.00, 0.61, 0.00)
RegPT(Enum.PowerType.Essence,     "Essence",     0.31, 1.00, 0.74)

-- Build the fast enumKey→colour lookup; reads from global SavedVariables when available.
-- Called at PLAYER_LOGIN (after DB is loaded) and whenever the user edits a colour.
local POWER_COLORS = {}
function UnitFramesLite_RebuildPowerColors()
    local ptDB = UnitFramesLiteDB and UnitFramesLiteDB.powerTypeColors
    for _, entry in ipairs(POWER_TYPE_LIST) do
        local c = (ptDB and ptDB[entry.dbKey]) or POWER_TYPE_DEFAULTS[entry.dbKey]
        POWER_COLORS[entry.enumKey] = c
    end
end
-- Seed with defaults so colours are available before PLAYER_LOGIN
UnitFramesLite_RebuildPowerColors()

-- Expose to options file
UFL.POWER_TYPE_LIST     = POWER_TYPE_LIST
UFL.POWER_TYPE_DEFAULTS = POWER_TYPE_DEFAULTS

-- Secondary resource (class resource) power types and max counts.
-- hideWhenEmpty: true  → pip hidden entirely when inactive (Soul Shards, Arcane Charges, Essence)
--               false → pip shows a dim background when inactive (Combo Points, Holy Power, Chi, Runes)
-- fractional:   true  → UnitPower unmodified=true; value is divided by 10 for per-pip fill fraction
--                        (Warlock Soul Shards: 0-50 range, each 10 = one full shard)
-- catFormOnly:  true  → bar only visible while player's primary power is Energy (Feral/cat form)
local CLASS_RESOURCES = {
    ROGUE       = { powerType = Enum.PowerType.ComboPoints,   maxPips = 7, hideWhenEmpty = false },
    DRUID       = { powerType = Enum.PowerType.ComboPoints,   maxPips = 7, hideWhenEmpty = false, catFormOnly = true },
    PALADIN     = { powerType = Enum.PowerType.HolyPower,     maxPips = 5, hideWhenEmpty = false },
    MONK        = { powerType = Enum.PowerType.Chi,           maxPips = 6, hideWhenEmpty = false },
    WARLOCK     = { powerType = Enum.PowerType.SoulShards,    maxPips = 5, hideWhenEmpty = true, fractional = true },
    DEATHKNIGHT = { powerType = nil, isRunes = true,          maxPips = 6, hideWhenEmpty = false },
    MAGE        = { powerType = Enum.PowerType.ArcaneCharges, maxPips = 4, hideWhenEmpty = true },
    EVOKER      = { powerType = Enum.PowerType.Essence,       maxPips = 6, hideWhenEmpty = true },
}

local RESOURCE_COLORS = {
    [Enum.PowerType.ComboPoints]   = {1.00, 0.96, 0.41},
    [Enum.PowerType.HolyPower]     = {0.95, 0.90, 0.10},
    [Enum.PowerType.Chi]           = {0.71, 0.96, 0.71},
    [Enum.PowerType.SoulShards]    = {0.50, 0.32, 0.55},
    [Enum.PowerType.ArcaneCharges] = {0.40, 0.60, 1.00},
    [Enum.PowerType.Essence]       = {0.31, 1.00, 0.74},
    runes                          = {0.77, 0.12, 0.23},
}

local function GetPowerColor(unit)
    local pt = UnitPowerType(unit)
    return (pt and POWER_COLORS[pt]) or {0, 0, 1}
end

local function UpdatePowerColor(frame, unit)
    if not frame.power then return end
    local c = GetPowerColor(unit)
    frame.power:SetStatusBarColor(c[1], c[2], c[3], 1)
end

local function ApplyPowerRingColor(frame, unit)
    local db = GetDB(unit)
    local c
    if db.orbPowerRingUseFixedColor then
        c = db.orbPowerRingColor or {0, 0.5, 1, 1}
    else
        c = GetPowerColor(unit)
    end
    local fa = (db.orbPowerRingColor and db.orbPowerRingColor[4]) or 1
    if frame.powerRingFillR then frame.powerRingFillR:SetStatusBarColor(c[1], c[2], c[3], fa) end
    if frame.powerRingFillL then frame.powerRingFillL:SetStatusBarColor(c[1], c[2], c[3], fa) end
end

-- Resource pips (class resources: combo points, holy power, etc.) ------------

local resourceFrame      = nil   -- created once on PLAYER_LOGIN
local resourcePips       = {}
local resourceClass      = nil
local resourceMaxPips    = 0     -- live value from UnitPowerMax; updated in SetupResourcePips
local testResourceActive = false -- set by UnitFramesLite_SetTestResource
local UpdateResourcePips  -- forward declaration so SetupResourcePips can call it

local function GetPlayerClass()
    local _, cls = UnitClass("player")
    return cls
end

-- Returns true if the resource bar should be suppressed due to a form/spec gate.
-- catFormOnly: Druid combo points only appear in cat form (primary power = Energy).
local function IsResourceGated(cfg)
    if not cfg then return true end
    if cfg.catFormOnly then
        local pt = UnitPowerType("player")
        return pt ~= Enum.PowerType.Energy
    end
    return false
end

local function SetupResourcePips()
    local cls = GetPlayerClass()
    resourceClass = cls
    local cfg = CLASS_RESOURCES[cls]
    if not cfg then
        if resourceFrame then resourceFrame:Hide() end
        return
    end

    local playerFrame = frames["player"]
    if not playerFrame then return end

    local db = GetDB("player")
    -- Derive the live pip count from the API; fall back to the cap if unavailable.
    local maxPips = cfg.maxPips  -- cap: maximum frames we ever create
    if not cfg.isRunes then
        local livePips = cfg.powerType and UnitPowerMax("player", cfg.powerType)
        if livePips and livePips > 0 then
            maxPips = math.min(livePips, cfg.maxPips)
        end
    end
    resourceMaxPips = maxPips

    if not resourceFrame then
        resourceFrame = CreateFrame("Frame", "UFL_ResourceFrame", UIParent)
        resourceFrame:SetMovable(true)
        resourceFrame:EnableMouse(false)
    end

    -- Build pips — always create up to the class cap so frames exist for any talent configuration.
    for i = 1, cfg.maxPips do
        if not resourcePips[i] then
            local pip = CreateFrame("StatusBar", nil, resourceFrame)

            -- Border: a texture on pip at BACKGROUND sublevel -7.
            -- pip.bg is at sublevel -8 (below border), StatusBar fill is above both.
            -- Textures can be anchored/sized outside their parent frame's bounds.
            -- borderTex lives on bgFrame (transparent Frame on resourceFrame) so it
            -- composites against the world rather than the StatusBar's opaque background.
            -- It is sized larger than the pip to form a border ring; shapeBg/pip.bg
            -- render on top covering the interior, leaving only the ring visible.
            -- (borderTex and borderMask are created after bgFrame below)

            pip:SetStatusBarTexture("Interface\\Buttons\\WHITE8X8")
            pip:SetMinMaxValues(0, 1)
            pip:SetValue(0)
            -- bgFrame: a plain transparent Frame parented to resourceFrame so its
            -- background textures composite against the world (not the StatusBar pip
            -- which has an inherent opaque black background).  We sync show/hide via
            -- pip's OnShow/OnHide hooks below.
            local bgFrame = CreateFrame("Frame", nil, resourceFrame)
            bgFrame:SetSize(1, 1)  -- sized in UpdateResourceLayout loop
            bgFrame:SetFrameLevel(pip:GetFrameLevel())
            pip.bgFrame = bgFrame
            pip:HookScript("OnShow", function() bgFrame:Show() end)
            pip:HookScript("OnHide", function() bgFrame:Hide() end)
            -- Border texture on bgFrame at lowest sublevel — pip bg/shapeBg at higher
            -- sublevels cover the interior; only the ring extending beyond pip size shows.
            local borderTex = bgFrame:CreateTexture(nil, "BACKGROUND", nil, -7)
            borderTex:SetAllPoints(bgFrame)
            borderTex:SetColorTexture(0, 0, 0, 1)
            borderTex:Hide()
            pip.borderTex = borderTex
            -- Mask texture for Circle/Diamond shaped borders (on bgFrame)
            local borderMask = bgFrame:CreateMaskTexture()
            borderMask:SetAllPoints(bgFrame)
            pip.borderMask = borderMask

            local bg = bgFrame:CreateTexture(nil, "BACKGROUND", nil, -6)
            bg:SetAllPoints(bgFrame)
            bg:SetColorTexture(0.1, 0.1, 0.1, 0.8)
            pip.bg = bg
            -- Shape mask (applied/removed in UpdateResourceLayout)
            local mask = pip:CreateMaskTexture()
            mask:SetAllPoints()
            pip.shapeMask = mask
            -- Pre-create BG mask too (on bgFrame so it composites correctly)
            local bgMask = bgFrame:CreateMaskTexture()
            bgMask:SetAllPoints(bgFrame)
            pip.bgMask = bgMask
            pip.borderFrame = borderFrame
            resourcePips[i] = pip
        end
    end
    -- Hide pips beyond the live count
    for i = maxPips + 1, #resourcePips do
        resourcePips[i]:Hide()
        if resourcePips[i].borderTex then resourcePips[i].borderTex:Hide() end
    end

    UnitFramesLite_UpdateResourceLayout()
    -- Immediately populate pip values so colours show on first frame after login/reload
    if UpdateResourcePips then UpdateResourcePips() end
end

function UnitFramesLite_UpdateResourceLayout()
    local playerFrame = frames["player"]
    if not playerFrame or not resourceFrame then return end
    local db = GetDB("player")
    local cls = resourceClass
    local cfg = cls and CLASS_RESOURCES[cls]
    if not cfg then
        if testResourceActive then
            cfg = { powerType = Enum.PowerType.ComboPoints, maxPips = 5, hideWhenEmpty = false }
        else
            resourceFrame:Hide()
            return
        end
    end

    if db.showResources == false and not testResourceActive then resourceFrame:Hide(); return end

    local maxPips = resourceMaxPips > 0 and resourceMaxPips or cfg.maxPips
    local pipW    = db.resourcePipWidth   or 18
    local pipH    = db.resourcePipHeight  or 6
    local pipGap  = db.resourcePipGap     or 3
    local totalW  = maxPips * pipW + (maxPips - 1) * pipGap
    resourceFrame:SetSize(totalW, pipH)

    -- Position: anchored to screen centre; x=0,y=0 places the bar at the centre of the screen.
    -- Clamp so the frame stays fully within the screen bounds.
    resourceFrame:ClearAllPoints()
    local rx = db.resourceX or 0
    local ry = db.resourceY or 0
    local screenW = UIParent:GetWidth()
    local screenH = UIParent:GetHeight()
    local halfFrameW = totalW / 2
    local halfFrameH = pipH  / 2
    local halfScreenW = screenW / 2
    local halfScreenH = screenH / 2
    rx = math.max(-(halfScreenW - halfFrameW), math.min(halfScreenW - halfFrameW, rx))
    ry = math.max(-(halfScreenH - halfFrameH), math.min(halfScreenH - halfFrameH, ry))
    resourceFrame:SetPoint("CENTER", UIParent, "CENTER", rx, ry)

    -- Colour
    local useCustom  = db.resourceUseCustomColor
    -- Support both old resourceUseSolidColor and new resourceColorMode
    local colorMode = db.resourceColorMode or (db.resourceUseSolidColor ~= false and "Solid" or "Horizontal Gradient")
    if colorMode == "Gradient" then colorMode = "Horizontal Gradient" end  -- migrate old value
    local useSolid  = (colorMode == "Solid")
    local gradPerPip = db.resourceGradPerPip ~= false     -- default true
    local gs = db.resourceGradStart or {1, 1, 1, 1}
    local ge = db.resourceGradEnd   or {0.3, 0.3, 1, 1}
    local col  -- fallback solid (class colour or custom solid)
    if useCustom then
        col = db.resourceSolidColor or {1, 1, 1, 1}
    elseif cfg.isRunes then
        col = RESOURCE_COLORS.runes
    else
        col = RESOURCE_COLORS[cfg.powerType] or {1, 1, 1}
    end

    local shape = db.resourcePipShape or "Rectangle"

    -- Helper: apply colour to a texture based on current colour settings (Rectangle/StatusBar only).
    -- SetGradient is safe here because StatusBar visibility is controlled by SetValue, not SetAlpha.
    local function ApplyColourToTex(tex, i)
        if not tex then return end
        if useCustom and not useSolid then
            local gradDir = (colorMode == "Vertical Gradient") and "VERTICAL" or "HORIZONTAL"
            if gradPerPip or colorMode == "Vertical Gradient" then
                tex:SetGradient(gradDir,
                    CreateColor(gs[1], gs[2], gs[3], gs[4] or 1),
                    CreateColor(ge[1], ge[2], ge[3], ge[4] or 1))
            else
                local t = maxPips > 1 and (i - 1) / (maxPips - 1) or 0
                local r = gs[1] + (ge[1] - gs[1]) * t
                local g = gs[2] + (ge[2] - gs[2]) * t
                local b = gs[3] + (ge[3] - gs[3]) * t
                tex:SetVertexColor(r, g, b, 1)
            end
        else
            local a = db.resourceAlpha or 1.0
            tex:SetVertexColor(col[1], col[2], col[3], a)
        end
    end

    -- Helper: apply colour to a shaped pip's fill texture and store the colour info on the pip
    -- so UpdateResourcePips can reapply it with the correct fill alpha later.
    -- Shaped pips use vertex colour alpha (not SetAlpha) to avoid SetGradient resetting SetAlpha.
    local function ApplyShapedPipColour(pip, sf, i)
        if not sf then return end
        if useCustom and not useSolid then
            local isVertical = (colorMode == "Vertical Gradient")
            if gradPerPip or isVertical then
                local gradDir = isVertical and "VERTICAL" or "HORIZONTAL"
                pip.shapeFillGradient = {
                    dir = gradDir,
                    r1 = gs[1], g1 = gs[2], b1 = gs[3], a1 = gs[4] or 1,
                    r2 = ge[1], g2 = ge[2], b2 = ge[3], a2 = ge[4] or 1,
                }
                pip.shapeFillColor = nil
                -- Apply with fillFrac=1; UpdateResourcePips reapplies with correct active alpha.
                sf:SetGradient(gradDir,
                    CreateColor(gs[1], gs[2], gs[3], gs[4] or 1),
                    CreateColor(ge[1], ge[2], ge[3], ge[4] or 1))
            else
                -- Horizontal, spread across bar: interpolated solid colour per pip position.
                pip.shapeFillGradient = nil
                local t = maxPips > 1 and (i - 1) / (maxPips - 1) or 0
                local r = gs[1] + (ge[1] - gs[1]) * t
                local g = gs[2] + (ge[2] - gs[2]) * t
                local b = gs[3] + (ge[3] - gs[3]) * t
                local a = (gs[4] or 1) + ((ge[4] or 1) - (gs[4] or 1)) * t
                pip.shapeFillColor = {r, g, b, a}
                sf:SetVertexColor(r, g, b, a)
            end
        else
            pip.shapeFillGradient = nil
            local a = col[4] or (db.resourceAlpha or 1.0)
            pip.shapeFillColor = {col[1], col[2], col[3], a}
            sf:SetVertexColor(col[1], col[2], col[3], a)
        end
    end

    for i = 1, maxPips do
        local pip = resourcePips[i]
        if pip then
            pip:SetSize(pipW, pipH)
            pip:ClearAllPoints()
            pip:SetPoint("LEFT", resourceFrame, "LEFT", (i-1) * (pipW + pipGap), 0)
            -- Keep bgFrame (transparent Frame on resourceFrame) in sync with pip
            if pip.bgFrame then
                pip.bgFrame:SetSize(pipW, pipH)
                pip.bgFrame:ClearAllPoints()
                pip.bgFrame:SetPoint("LEFT", resourceFrame, "LEFT", (i-1) * (pipW + pipGap), 0)
            end

            -- ── Apply colour to StatusBar-based pips ──────────────────────────
            local function ApplyStatusBarColour()
                local fillTex = pip:GetStatusBarTexture()
                if useCustom and not useSolid then
                    local gradDir = (colorMode == "Vertical Gradient") and "VERTICAL" or "HORIZONTAL"
                    if gradPerPip or colorMode == "Vertical Gradient" then
                        pip:SetStatusBarColor(1, 1, 1, 1)
                        if fillTex then
                            fillTex:SetGradient(gradDir,
                                CreateColor(gs[1], gs[2], gs[3], gs[4] or 1),
                                CreateColor(ge[1], ge[2], ge[3], ge[4] or 1))
                        end
                    else
                        local t = maxPips > 1 and (i - 1) / (maxPips - 1) or 0
                        local r2 = gs[1] + (ge[1] - gs[1]) * t
                        local g2 = gs[2] + (ge[2] - gs[2]) * t
                        local b2 = gs[3] + (ge[3] - gs[3]) * t
                        if fillTex then fillTex:SetGradient("HORIZONTAL", CreateColor(1,1,1,1), CreateColor(1,1,1,1)) end
                        pip:SetStatusBarColor(r2, g2, b2, 1)
                    end
                else
                    if fillTex then fillTex:SetGradient("HORIZONTAL", CreateColor(1,1,1,1), CreateColor(1,1,1,1)) end
                    local a = db.resourceAlpha or 1.0
                    pip:SetStatusBarColor(col[1], col[2], col[3], a)
                end
            end

            -- Restore StatusBar visibility and remove shaped textures when switching to bar-based shapes
            local function EnterStatusBarMode()
                pip.isShapedPip = false
                pip:SetAlpha(1)
                -- Remove any masks from shaped textures before hiding them
                pcall(function() if pip.shapeFill and pip.shapeMask then pip.shapeFill:RemoveMaskTexture(pip.shapeMask) end end)
                pcall(function() if pip.shapeBg   and pip.bgMask    then pip.shapeBg:RemoveMaskTexture(pip.bgMask)     end end)
                if pip.shapeFill then pip.shapeFill:Hide() end
                if pip.shapeBg   then pip.shapeBg:Hide()   end
                -- Remove any masks from pip.bg (applied by Circle mode) then restore it
                pcall(function() if pip.bg and pip.bgMask then pip.bg:RemoveMaskTexture(pip.bgMask) end end)
                if pip.bg then pip.bg:Show(); local bc = db.resourcePipBgColor or {0.1,0.1,0.1,0.8}; pip.bg:SetColorTexture(bc[1],bc[2],bc[3],bc[4] or 0.8) end
            end

            -- Set up shaped textures for non-StatusBar shapes (Diamond, Triangle, Arrow)
            local function EnterShapedMode()
                pip.isShapedPip = true
                pip:SetAlpha(1)
                local fillTex = pip:GetStatusBarTexture()
                -- Remove masks from StatusBar fill and pip.bg
                pcall(function() if fillTex and pip.shapeMask then fillTex:RemoveMaskTexture(pip.shapeMask) end end)
                pcall(function() if pip.bg and pip.bgMask then pip.bg:RemoveMaskTexture(pip.bgMask) end end)
                -- Remove circle masks from shaped textures if switching between shaped shapes (e.g. Circle->Diamond)
                pcall(function() if pip.shapeFill and pip.shapeMask then pip.shapeFill:RemoveMaskTexture(pip.shapeMask) end end)
                pcall(function() if pip.shapeBg   and pip.bgMask    then pip.shapeBg:RemoveMaskTexture(pip.bgMask)     end end)
                pip:SetStatusBarColor(0, 0, 0, 0)
                -- Hide the StatusBar bg rectangle — shaped pips draw their own bg via shapeBg texture
                if pip.bg then pip.bg:Hide() end
                if not pip.shapeFill then pip.shapeFill = pip:CreateTexture(nil, "ARTWORK") end
                if not pip.shapeBg   then pip.shapeBg   = pip.bgFrame:CreateTexture(nil, "BACKGROUND") end
            end

            -- ── Border ────────────────────────────────────────────────────────
            -- pip.borderTex is at BACKGROUND sublevel -7 on the pip itself.
            -- pip.bg  is at sublevel -8 (darkens background, below border tex).
            -- StatusBar fill renders above all BACKGROUND sublevels.
            local borderEnabled   = db.resourcePipBorderEnabled
            local borderThickness = db.resourcePipBorderThickness or 1
            local borderColor     = db.resourcePipBorderColor or {0, 0, 0, 1}
            local bt = pip.borderTex
            local bm = pip.borderMask
            if bt then
                pcall(function() bt:RemoveMaskTexture(bm) end)
                if borderEnabled then
                    local t  = borderThickness
                    local bc = borderColor
                    bt:SetTexture("Interface\\Buttons\\WHITE8X8")
                    bt:SetVertexColor(bc[1], bc[2], bc[3], bc[4] or 1)
                    if shape == "Circle" then
                        local circSize = math.min(pipW, pipH) + t * 2
                        bt:ClearAllPoints()
                        bt:SetSize(circSize, circSize)
                        bt:SetPoint("CENTER", pip, "CENTER", 0, 0)
                        bt:SetRotation(0)
                        if bm then
                            bm:SetTexture("Interface\\CharacterFrame\\TempPortraitAlphaMask")
                            bm:ClearAllPoints(); bm:SetSize(circSize, circSize)
                            bm:SetPoint("CENTER", pip, "CENTER", 0, 0)
                            pcall(function() bt:AddMaskTexture(bm) end)
                        end
                    elseif shape == "Diamond" then
                        local outerS = math.min(pipW, pipH) / math.sqrt(2) + t * math.sqrt(2)
                        bt:ClearAllPoints()
                        bt:SetSize(outerS, outerS)
                        bt:SetPoint("CENTER", pip, "CENTER", 0, 0)
                        bt:SetRotation(math.pi / 4)
                    else -- Rectangle
                        bt:ClearAllPoints()
                        bt:SetSize(pipW + t * 2, pipH + t * 2)
                        bt:SetPoint("CENTER", pip, "CENTER", 0, 0)
                        bt:SetRotation(0)
                    end
                    bt:Show()
                else
                    bt:Hide()
                end
            end

            if shape == "Rectangle" then
                EnterStatusBarMode()
                ApplyStatusBarColour()
                local fillTex = pip:GetStatusBarTexture()
                pcall(function() if fillTex and pip.shapeMask then fillTex:RemoveMaskTexture(pip.shapeMask) end end)
                pcall(function() if pip.bg and pip.bgMask then pip.bg:RemoveMaskTexture(pip.bgMask) end end)

            elseif shape == "Circle" then
                -- Use full-coverage textures masked to a circle so active/inactive
                -- can be shown by alpha, not by StatusBar fill percentage.
                EnterShapedMode()
                local sf, sb = pip.shapeFill, pip.shapeBg
                local circSize = math.min(pipW, pipH)
                sf:SetTexture("Interface\\Buttons\\WHITE8X8")
                sf:SetRotation(0)
                sf:SetSize(circSize, circSize)
                sf:ClearAllPoints(); sf:SetPoint("CENTER", pip, "CENTER", 0, 0)
                sb:SetTexture("Interface\\Buttons\\WHITE8X8")
                sb:SetRotation(0)
                sb:SetSize(circSize, circSize)
                sb:ClearAllPoints(); sb:SetPoint("CENTER", pip, "CENTER", 0, 0)
                do local bc = db.resourcePipBgColor or {0.1,0.1,0.1,0.8}; sb:SetVertexColor(bc[1],bc[2],bc[3],bc[4] or 0.8) end
                -- Apply circle mask to both fill and bg textures
                if pip.shapeMask then
                    pip.shapeMask:SetTexture("Interface\\CharacterFrame\\TempPortraitAlphaMask")
                    pip.shapeMask:SetAllPoints(pip)
                    pcall(function() sf:AddMaskTexture(pip.shapeMask) end)
                end
                if pip.bgMask then
                    pip.bgMask:SetTexture("Interface\\CharacterFrame\\TempPortraitAlphaMask")
                    pip.bgMask:SetAllPoints(pip)
                    pcall(function() sb:AddMaskTexture(pip.bgMask) end)
                end
                ApplyShapedPipColour(pip, sf, i)
                sf:Show(); sb:Show()

            elseif shape == "Diamond" then
                -- Rotate a square texture 45°. A square of side s has diagonal s*√2.
                -- To fill the pip bounds (pipW × pipH), use s = min(pipW,pipH)/√2 so
                -- the rotated corners touch the pip edges.
                EnterShapedMode()
                local s = math.min(pipW, pipH) / math.sqrt(2)
                local sf, sb = pip.shapeFill, pip.shapeBg
                sf:SetTexture("Interface\\Buttons\\WHITE8X8")
                sf:SetRotation(math.pi / 4)
                sf:SetSize(s, s)
                sf:ClearAllPoints(); sf:SetPoint("CENTER", pip, "CENTER", 0, 0)
                sb:SetTexture("Interface\\Buttons\\WHITE8X8")
                sb:SetRotation(math.pi / 4)
                sb:SetSize(s, s)
                sb:ClearAllPoints(); sb:SetPoint("CENTER", pip, "CENTER", 0, 0)
                do local bc = db.resourcePipBgColor or {0.1,0.1,0.1,0.8}; sb:SetVertexColor(bc[1],bc[2],bc[3],bc[4] or 0.8) end
                ApplyShapedPipColour(pip, sf, i)
                sf:Show(); sb:Show()

            end

            pip:Show()
        end
    end

    resourceFrame:Show()
    if UpdateResourcePips then UpdateResourcePips() end
end

local runeUpdateElapsed = 0
local RUNE_UPDATE_RATE  = 0.05

-- Applies fill alpha to a shaped pip's fill texture using stored gradient/colour info.
-- Kept at module scope so both UpdateResourcePips and the test-mode path can call it.
local function ApplyShapedFillAlpha(pip, fillFrac)
    local sf = pip.shapeFill
    if sf then
        if pip.shapeFillGradient then
            local gd = pip.shapeFillGradient
            sf:SetGradient(gd.dir,
                CreateColor(gd.r1, gd.g1, gd.b1, (gd.a1 or 1) * fillFrac),
                CreateColor(gd.r2, gd.g2, gd.b2, (gd.a2 or 1) * fillFrac))
        else
            local vc = pip.shapeFillColor or {1, 1, 1, 1}
            sf:SetVertexColor(vc[1], vc[2], vc[3], (vc[4] or 1) * fillFrac)
        end
    end
    if pip.shapeFill2 then pip.shapeFill2:SetAlpha(fillFrac) end
end

UpdateResourcePips = function()
    if not resourceFrame then return end
    local cls = resourceClass
    local cfg = cls and CLASS_RESOURCES[cls]
    if not cfg then return end

    local maxPips = resourceMaxPips > 0 and resourceMaxPips or cfg.maxPips

    -- In test mode, fill all pips to full so the user can see and adjust the layout.
    if testResourceActive then
        for i = 1, maxPips do
            local pip = resourcePips[i]
            if pip then
                pip:Show()
                if pip.isShapedPip then
                    ApplyShapedFillAlpha(pip, 1)
                else
                    pip:SetValue(1); pip:SetAlpha(1)
                end
            end
        end
        return
    end

    if cfg.isRunes then
        -- Death Knight runes: use GetRuneCooldown
        for i = 1, 6 do
            local pip = resourcePips[i]
            if pip then
                local start, duration, ready = GetRuneCooldown(i)
                if ready then
                    if pip.isShapedPip then
                        ApplyShapedFillAlpha(pip, 1)
                    else
                        pip:SetValue(1); pip:SetAlpha(1)
                    end
                else
                    local now = GetTime()
                    local elapsed = now - (start or now)
                    local frac = duration and duration > 0 and (elapsed / duration) or 0
                    if pip.isShapedPip then
                        ApplyShapedFillAlpha(pip, math.max(0, math.min(1, frac)))
                    else
                        pip:SetValue(math.max(0, math.min(1, frac))); pip:SetAlpha(0.4)
                    end
                end
            end
        end
    else
        -- All other class resources
        local hideWhenEmpty = cfg.hideWhenEmpty
        local isFractional  = cfg.fractional

        -- UnitPower/UnitPowerMax can return secret numbers in 12.0 for some power types.
        -- All comparisons involving these values must be inside pcall.
        -- cur/max are captured by closure so pcall callbacks can write them.
        local cur = 0
        local max = maxPips
        pcall(function()
            local m = UnitPowerMax("player", cfg.powerType)
            if m and m > 0 then max = math.min(m, maxPips) end
        end)
        if isFractional then
            -- Soul Shards: unmodified 0-50 range; each 10 units = 1 full shard.
            -- Arithmetic on secret values is also forbidden, so wrap in pcall.
            pcall(function() cur = UnitPower("player", cfg.powerType, true) end)
        else
            pcall(function() cur = UnitPower("player", cfg.powerType) end)
        end

        for i = 1, maxPips do
            local pip = resourcePips[i]
            if pip then
                local overMax = false
                pcall(function() overMax = (i > max) end)
                if overMax then
                    pip:Hide()
                else
                    -- Determine fill fraction for this pip (0–1) inside pcall since
                    -- comparing/doing arithmetic with secret numbers throws.
                    local fillFrac = 0
                    if isFractional then
                        pcall(function()
                            local pipMin = (i - 1) * 10
                            fillFrac = math.max(0, math.min(1, (cur - pipMin) / 10))
                        end)
                    else
                        pcall(function() fillFrac = (cur >= i) and 1 or 0 end)
                    end

                    local active = fillFrac > 0

                    if hideWhenEmpty and not active then
                        pip:Hide()
                    else
                        pip:Show()
                        if pip.isShapedPip then
                            ApplyShapedFillAlpha(pip, fillFrac)
                        else
                            pip:SetValue(fillFrac)
                            pip:SetAlpha(active and 1 or 0.35)
                        end
                    end
                end
            end
        end
    end
end

-- Hook OnUpdate on the event frame for rune smooth updates
local resourceOnUpdateRegistered = false
local function RegisterResourceOnUpdate(eventFrame)
    if resourceOnUpdateRegistered then return end
    resourceOnUpdateRegistered = true
    eventFrame:HookScript("OnUpdate", function(self, elapsed)
        if resourceClass == "DEATHKNIGHT" and resourceFrame and resourceFrame:IsShown() then
            runeUpdateElapsed = runeUpdateElapsed + elapsed
            if runeUpdateElapsed >= RUNE_UPDATE_RATE then
                runeUpdateElapsed = 0
                UpdateResourcePips()
            end
        end
    end)
end

-- Update frame layout --------------------------------------------------------

function UnitFramesLite_UpdateFrame(unit)
    local frame = frames[unit]
    if not frame then return end
    local db = GetDB(unit)

    local w = db.frameWidth  or 160
    local h = db.frameHeight or 35
    frame:SetSize(w, h)
    frame:ClearAllPoints()
    frame:SetPoint("CENTER", UIParent, "CENTER", db.x or 0, db.y or 0)

    local br, bg, bb, ba = unpack(db.barBG)
    frame.bg:SetColorTexture(br, bg, bb, ba)

    local barH = (db.hpBarHeight and db.hpBarHeight > 0) and math.min(db.hpBarHeight, h) or h

    if db.sphereMode then
        -- ── Orb / sphere mode ─────────────────────────────────────────────
        frame.hp:Hide()
        if frame.power then frame.power:Hide() end
        frame.bg:SetColorTexture(0, 0, 0, 0)
        if frame.portraitFrame then frame.portraitFrame:Hide() end

        local sz          = math.max(20, db.sphereSize or 80)
        local fillDir     = db.sphereFillDir  or "VERTICAL"
        local gradDir     = db.orbGradientDir or "VERTICAL"
        local orbFrame    = frame.orbFrame
        orbFrame:SetSize(sz, sz)
        orbFrame:ClearAllPoints()
        orbFrame:SetPoint("CENTER", frame, "CENTER", 0, 0)
        orbFrame:Show()

        -- Background circle
        local bc = db.orbBgColor or {0, 0, 0, 0.9}
        frame.orbBg:SetColorTexture(bc[1], bc[2], bc[3], bc[4] or 0.9)
        if frame.powerRingCentreCover then
            frame.powerRingCentreCover:SetColorTexture(bc[1], bc[2], bc[3], bc[4] or 0.9)
        end

        -- Fill bars
        -- When Gradient Direction is CENTRE the orb is split into lower and upper
        -- halves. Each half tracks health independently (scaled per-half via Update).
        -- The reversed gradient on the lower half ensures both halves meet at the
        -- orbGradientStart colour at the centre, creating a seamless radial glow.
        if gradDir == "CENTRE" then
            local halfSz = sz / 2
            -- Lower half (bottom of orb)
            frame.orbFill:ClearAllPoints()
            frame.orbFill:SetPoint("BOTTOMLEFT", orbFrame, "BOTTOMLEFT", 0, 0)
            frame.orbFill:SetSize(sz, halfSz)
            frame.orbFill:SetOrientation(fillDir)
            frame.orbFill:SetReverseFill(db.reverseFill or false)
            ApplyOrbFill(frame.orbFill, db, frame.orbCircleMask, true, unit)   -- reversed gradient
            if frame.orbFill2 then
                -- Upper half (top of orb)
                frame.orbFill2:ClearAllPoints()
                frame.orbFill2:SetPoint("TOPLEFT", orbFrame, "TOPLEFT", 0, 0)
                frame.orbFill2:SetSize(sz, halfSz)
                frame.orbFill2:SetOrientation(fillDir)
                frame.orbFill2:SetReverseFill(db.reverseFill or false)
                ApplyOrbFill(frame.orbFill2, db, frame.orbCircleMask, false, unit)  -- normal gradient
                frame.orbFill2:Show()
            end
        else
            frame.orbFill:ClearAllPoints()
            frame.orbFill:SetAllPoints(orbFrame)
            frame.orbFill:SetOrientation(fillDir)
            frame.orbFill:SetReverseFill(db.reverseFill or false)
            ApplyOrbFill(frame.orbFill, db, frame.orbCircleMask, nil, unit)
            if frame.orbFill2 then frame.orbFill2:Hide() end
        end

        -- Inner border (donut ring just outside the health orb)
        if db.showOrbBorder and frame.orbBorderFrame then
            local bt = math.max(1, db.orbBorderThickness or 4)
            local borderSz = sz + bt * 2
            frame.orbBorderFrame:SetSize(borderSz, borderSz)
            frame.orbBorderFrame:ClearAllPoints()
            frame.orbBorderFrame:SetPoint("CENTER", frame, "CENTER", 0, 0)
            frame.orbBorderTex:SetTexture(ChooseRingTexture(borderSz))
            local bc = db.orbBorderColor or {0, 0, 0, 1}
            frame.orbBorderTex:SetVertexColor(bc[1], bc[2], bc[3], bc[4])
            frame.orbBorderFrame:Show()
        elseif frame.orbBorderFrame then
            frame.orbBorderFrame:Hide()
        end

        -- Power ring / bar
        local pMode = db.orbPowerMode or "None"

        if pMode == "Ring" and frame.powerRingFrame then
            local thick    = math.max(4, db.orbPowerRingThickness or 8)
            local ringSz   = sz + thick * 2
            local prf      = frame.powerRingFrame
            prf:SetSize(ringSz, ringSz)
            prf:ClearAllPoints()
            prf:SetPoint("CENTER", orbFrame, "CENTER", 0, 0)

            local rc = db.orbPowerRingBgColor or {0, 0, 0, 0.9}
            frame.powerRingBg:SetColorTexture(rc[1], rc[2], rc[3], rc[4])

            local function SetupRingBar(bar)
                bar:SetStatusBarTexture("Interface\\Buttons\\WHITE8X8")
                local st = bar:GetStatusBarTexture()
                if st and frame.powerRingCircMask then st:AddMaskTexture(frame.powerRingCircMask) end
            end

            local ccw = db.orbPowerRingCCW or false
            local halfRing = ringSz / 2
            frame.powerRingFillL:ClearAllPoints()
            frame.powerRingFillL:SetPoint("TOPLEFT", prf, "TOPLEFT", 0, 0)
            frame.powerRingFillL:SetSize(halfRing, ringSz)
            frame.powerRingFillL:SetOrientation("VERTICAL")
            frame.powerRingFillL:SetReverseFill(not ccw)
            SetupRingBar(frame.powerRingFillL)
            frame.powerRingFillR:ClearAllPoints()
            frame.powerRingFillR:SetPoint("TOPRIGHT", prf, "TOPRIGHT", 0, 0)
            frame.powerRingFillR:SetSize(halfRing, ringSz)
            frame.powerRingFillR:SetOrientation("VERTICAL")
            frame.powerRingFillR:SetReverseFill(ccw)
            SetupRingBar(frame.powerRingFillR)

            ApplyPowerRingColor(frame, unit)

            -- Size the centre cover to the orb and colour it with orbBgColor so the
            -- ring BG is only visible in the ring band, not behind the health orb.
            if frame.powerRingCentreCover then
                frame.powerRingCentreCover:SetSize(sz, sz)
                frame.powerRingCentreMask:SetSize(sz, sz)
                frame.powerRingCentreMask:SetPoint("CENTER", prf, "CENTER", 0, 0)
                local bc = db.orbBgColor or {0, 0, 0, 0.9}
                frame.powerRingCentreCover:SetColorTexture(bc[1], bc[2], bc[3], bc[4] or 0.9)
            end

            prf:Show()
        else
            if frame.powerRingFrame then frame.powerRingFrame:Hide() end
        end

        if pMode == "Bar" and frame.orbPowerBar then
            local pb  = frame.orbPowerBar
            local bw  = db.orbPowerBarWidth    or 80
            local bh  = db.orbPowerBarHeight   or 12
            local bx  = db.orbPowerBarX        or 0
            local by  = db.orbPowerBarY        or 0
            local fd  = db.orbPowerBarFillDir  or "HORIZONTAL"
            pb:SetSize(bw, bh)
            pb:ClearAllPoints()
            if db.orbPowerBarCentreToScreen then
                pb:SetPoint("CENTER", UIParent, "CENTER", 0, by)
            else
                pb:SetPoint("CENTER", frame, "CENTER", bx, by)
            end
            pb:SetOrientation(fd)
            pb:SetReverseFill(db.reverseFill or false)
            local fc = (not db.orbPowerBarUseFixedColor) and GetPowerColor(unit)
                       or db.orbPowerBarColor or {0, 0.5, 1, 1}
            pb:SetStatusBarColor(fc[1], fc[2], fc[3], fc[4] or 1)
            if frame.orbPowerBarBg then
                local bc = db.orbPowerBarBgColor or {0, 0, 0, 0.9}
                frame.orbPowerBarBg:SetColorTexture(bc[1], bc[2], bc[3], bc[4] or 0.9)
            end
            -- Ensure bar has valid range so it renders before first event fires
            pb:SetMinMaxValues(0, 1); pb:SetValue(1)
            pb:Show()
        else
            if frame.orbPowerBar then frame.orbPowerBar:Hide() end
        end

        -- Text (uses Text tab settings, positioned relative to orb centre)
        if frame.nameText then
            local c = (db.nameColorByReaction and GetReactionColor(unit, db)) or db.nameColor or {1, 1, 1, 1}
            frame.nameText:SetFont(ResolveFont(db, "nameFont"), db.nameTextFontSize or 12, "OUTLINE")
            frame.nameText:SetTextColor(c[1], c[2], c[3], c[4])
            ApplyNameText(frame.nameText, frame, db,
                db.nameTextX or 0, (db.nameTextY or 0) + sz / 2 + 8)
        end
        if frame.hpText then
            local c = (db.hpTextColorByReaction and GetReactionColor(unit, db)) or db.hpTextColor or {1, 1, 1, 1}
            frame.hpText:SetFont(ResolveFont(db, "hpTextFont"), db.hpTextFontSize or 11, "OUTLINE")
            frame.hpText:SetTextColor(c[1], c[2], c[3], c[4])
            frame.hpText:ClearAllPoints()
            frame.hpText:SetPoint("CENTER", frame, "CENTER",
                db.hpTextX or 0, db.hpTextY or 0)
            frame.hpText:SetWidth(sz - 4)
            frame.hpText:SetJustifyH(string.upper(db.hpTextAlign or "CENTER"))
        end
        if frame.hpPctText then
            local c = (db.hpPctColorByReaction and GetReactionColor(unit, db)) or db.hpPctColor or {1, 1, 1, 1}
            frame.hpPctText:SetFont(ResolveFont(db, "hpPctFont"), db.hpPctFontSize or 11, "OUTLINE")
            frame.hpPctText:SetTextColor(c[1], c[2], c[3], c[4])
            frame.hpPctText:ClearAllPoints()
            frame.hpPctText:SetPoint("CENTER", frame, "CENTER",
                db.hpPctX or 0, db.hpPctY or -14)
            frame.hpPctText:SetWidth(sz - 4)
            frame.hpPctText:SetJustifyH(string.upper(db.hpPctAlign or "CENTER"))
        end
        if frame.levelText then
            local c = (db.levelColorByReaction and GetReactionColor(unit, db)) or db.levelColor or {1, 1, 1, 1}
            frame.levelText:SetFont(ResolveFont(db, "levelFont"), db.levelTextFontSize or 11, "OUTLINE")
            frame.levelText:SetTextColor(c[1], c[2], c[3], c[4])
            frame.levelText:ClearAllPoints()
            frame.levelText:SetPoint("CENTER", frame, "CENTER",
                db.levelTextX or 0, (db.levelTextY or 0) - sz / 2 - 8)
            frame.levelText:SetWidth(sz)
            frame.levelText:SetJustifyH(string.upper(db.levelTextAlign or "CENTER"))
        end

    else
        -- ── Bar mode ──────────────────────────────────────────────────────
        if frame.orbFrame        then frame.orbFrame:Hide()       end
        if frame.orbFill2        then frame.orbFill2:Hide()       end
        if frame.orbBorderFrame  then frame.orbBorderFrame:Hide() end
        if frame.powerRingFrame  then frame.powerRingFrame:Hide() end
        if frame.orbPowerBar     then frame.orbPowerBar:Hide()    end
        -- Portrait frame is hidden when sphere mode is active (handled in portrait block below)

        frame.hp:Show()
        frame.hp:SetWidth(w)

        if db.useSolidColor then
            local texPath = "Interface\\TARGETINGFRAME\\UI-StatusBar"
            if LSM and db.statusbarTexture then
                texPath = LSM:Fetch("statusbar", db.statusbarTexture) or texPath
            end
            frame.hp:SetStatusBarTexture(texPath)
            local sr, sg, sb, sa = unpack(db.solidColor)
            frame.hp:SetStatusBarColor(sr, sg, sb, sa)
        else
            frame.hp:SetStatusBarTexture("Interface\\Buttons\\WHITE8X8")
            frame.hp:SetStatusBarColor(1, 1, 1, 1)
            local dir = db.gradientDir or "HORIZONTAL"
            local sr, sg, sb, sa = unpack(db.gradientStart)
            local er, eg, eb, ea = unpack(db.gradientEnd)
            local sbTex = frame.hp:GetStatusBarTexture()
            if sbTex then
                sbTex:SetGradient(dir,
                    CreateColor(sr, sg, sb, sa), CreateColor(er, eg, eb, ea))
            end
        end
        frame.hp:SetReverseFill(db.reverseFill or false)

        if frame.power then
            frame.power:SetStatusBarTexture("Interface\\Buttons\\WHITE8X8")
            -- Bar mode power is enabled when orbPowerMode is "Bar" (or legacy showPowerBar)
            local barPowerEnabled = (db.orbPowerMode == "Bar") or
                                    (db.orbPowerMode == nil and db.showPowerBar)
            if barPowerEnabled then
                local attach = db.powerBarAttach ~= false  -- default true (attached)
                local maxPH  = math.max(1, math.floor(h / 2))
                local pH     = attach and math.max(1, math.min(db.orbPowerBarHeight or 8, maxPH))
                               or math.max(1, db.orbPowerBarHeight or 8)
                local pw     = attach and w or math.max(1, db.orbPowerBarWidth or w)
                frame.power:SetWidth(pw)
                frame.power:SetHeight(pH)
                frame.power:ClearAllPoints()
                if attach then
                    -- Attached: shrink health bar, anchor power bar to frame bottom
                    frame.hp:SetHeight(math.max(1, barH - pH))
                    frame.power:SetPoint("BOTTOMLEFT", frame, "BOTTOMLEFT", 0, 0)
                elseif db.orbPowerBarCentreToScreen then
                    -- Free-floating, centred on screen
                    frame.hp:SetHeight(barH)
                    local by = db.orbPowerBarY or 0
                    frame.power:SetPoint("CENTER", UIParent, "CENTER", 0, by)
                else
                    -- Free-floating with manual X/Y offset from frame centre
                    frame.hp:SetHeight(barH)
                    local bx = db.orbPowerBarX or 0
                    local by = db.orbPowerBarY or 0
                    frame.power:SetPoint("CENTER", frame, "CENTER", bx, by)
                end
                local fd = db.orbPowerBarFillDir or "HORIZONTAL"
                frame.power:SetOrientation(fd)
                frame.power:SetReverseFill(db.reverseFill or false)
                local fc = db.orbPowerBarUseTypeColor and GetPowerColor(unit)
                           or db.orbPowerBarColor or {0, 0.5, 1, 1}
                frame.power:SetStatusBarColor(fc[1], fc[2], fc[3], fc[4] or 1)
                if UnitHasPower(unit) then
                    frame.power:Show()
                else
                    frame.hp:SetHeight(barH)
                    frame.power:Hide()
                end
            else
                frame.hp:SetHeight(barH)
                frame.power:Hide()
            end
        else
            frame.hp:SetHeight(barH)
        end

        if frame.nameText then
            local c = (db.nameColorByReaction and GetReactionColor(unit, db)) or db.nameColor or {1,1,1,1}
            frame.nameText:SetFont(ResolveFont(db, "nameFont"), db.nameTextFontSize or 12, "OUTLINE")
            frame.nameText:SetTextColor(c[1], c[2], c[3], c[4])
            ApplyNameText(frame.nameText, frame, db, db.nameTextX or 0, db.nameTextY or 0)
        end
        ApplyTextElement(frame.hpText,    frame, ResolveFont(db, "hpTextFont"),
            db.hpTextFontSize    or 11,
            (db.hpTextColorByReaction and GetReactionColor(unit, db)) or db.hpTextColor or {1,1,1,1},
            db.hpTextX    or 0, db.hpTextY    or 0, db.hpTextAlign      or "CENTER")
        ApplyTextElement(frame.hpPctText, frame, ResolveFont(db, "hpPctFont"),
            db.hpPctFontSize     or 11,
            (db.hpPctColorByReaction  and GetReactionColor(unit, db)) or db.hpPctColor  or {1,1,1,1},
            db.hpPctX     or 0, db.hpPctY     or -14,   db.hpPctAlign   or "CENTER")
        ApplyTextElement(frame.levelText, frame, ResolveFont(db, "levelFont"),
            db.levelTextFontSize or 11,
            (db.levelColorByReaction  and GetReactionColor(unit, db)) or db.levelColor  or {1,1,1,1},
            db.levelTextX or 0, db.levelTextY or 0, db.levelTextAlign   or "CENTER")
    end

    -- Portrait (bar mode only) ------------------------------------------------
    if frame.portraitFrame then
        local pMode  = db.portraitMode or "None"
        local pSide  = db.portraitSide or "Left"
        local clamp  = db.portraitClamp ~= false

        if pMode == "None" or db.sphereMode then
            frame.portraitFrame:Hide()
        else
            local pf = frame.portraitFrame
            local pw, ph
            if clamp then
                -- Clamp: height = frame height, width = height (square)
                ph = h
                pw = h
            else
                pw = db.portraitW or h
                ph = db.portraitH or h
            end

            pf:SetSize(pw, ph)
            pf:ClearAllPoints()
            if clamp then
                -- Attach directly to the display frame edge
                if pSide == "Left" then
                    pf:SetPoint("RIGHT", frame, "LEFT", 0, 0)
                else
                    pf:SetPoint("LEFT",  frame, "RIGHT", 0, 0)
                end
            else
                -- Freely positioned relative to frame centre
                local px = db.portraitX or 0
                local py = db.portraitY or 0
                if pSide == "Left" then
                    pf:SetPoint("RIGHT", frame, "LEFT",  px, py)
                else
                    pf:SetPoint("LEFT",  frame, "RIGHT", px, py)
                end
            end

            -- Show correct sub-widget
            if pMode == "2D" then
                frame.portrait2D:Show()
                if frame.portrait3D then frame.portrait3D:Hide() end
                SetPortraitTexture(frame.portrait2D, unit)
            elseif pMode == "3D" then
                frame.portrait2D:Hide()
                if frame.portrait3D then
                    frame.portrait3D:Show()
                    frame.portrait3D:SetUnit(unit)
                end
            elseif pMode == "Unit Type" then
                frame.portrait2D:Hide()
                if frame.portrait3D then
                    frame.portrait3D:Show()
                    -- Use creature model for non-player-controlled units; player model otherwise
                    local isPlayer = UnitIsPlayer(unit)
                    if isPlayer then
                        frame.portrait3D:SetUnit(unit)
                    else
                        frame.portrait3D:SetCreature(UnitCreatureFamily(unit) or 0)
                        frame.portrait3D:SetUnit(unit)  -- fallback sets the model correctly
                    end
                end
            end

            pf:Show()
        end
    end

    -- Bar border: shown in bar mode only if barBorderEnabled, hidden in sphere mode
    if frame.borderFrame then
        if not db.sphereMode and db.barBorderEnabled ~= false then
            local t = math.max(1, db.barBorderThickness or 1)
            local c = db.barBorderColor or {0, 0, 0, 1}
            frame.borderFrame:SetBackdrop({
                edgeFile = "Interface\\Buttons\\WHITE8X8", edgeSize = t,
                insets   = {left=0, right=0, top=0, bottom=0},
            })
            frame.borderFrame:SetBackdropBorderColor(c[1], c[2], c[3], c[4])
            frame.borderFrame:Show()
        else
            frame.borderFrame:Hide()
        end
    end

    UnitFramesLite_UpdateVisibility(unit)
    UnitFramesLite_UpdateAlpha(unit)
    UnitFramesLite_UpdateEliteBorder(unit)
    if frame.OnUFLUpdate then frame:OnUFLUpdate() end
    if unit == "player" then
        if UnitFramesLite_UpdateResourceLayout then UnitFramesLite_UpdateResourceLayout() end
        if UnitFramesLite_UpdateResourceVisibility then UnitFramesLite_UpdateResourceVisibility() end
    end
end

function UnitFramesLite_SetPosition(unit, x, y)
    local db = GetDB(unit)
    db.x, db.y = x, y
    UnitFramesLite_UpdateFrame(unit)
end

function UnitFramesLite_GetDB(unit) return GetDB(unit) end

local function DeepCopyAllDB(src)
    if type(src) ~= "table" then return src end
    local t = {}
    for k, v in pairs(src) do t[k] = DeepCopyAllDB(v) end
    return t
end

-- Copy DB from src unit to dest unit, mirroring X positions if mirror=true
function UnitFramesLite_CopyUnit(srcUnit, destUnit, mirror)
    local src = GetDB(srcUnit)
    UnitFramesLiteDB[destUnit] = UnitFramesLiteDB[destUnit] or {}
    local dest = UnitFramesLiteDB[destUnit]
    local ox, oy = dest.x, dest.y
    -- Deep copy all settings
    for k, v in pairs(DeepCopyAllDB(src)) do dest[k] = v end
    -- Restore position (don't move the frame)
    dest.x = ox or dest.x
    dest.y = oy or dest.y
    -- Mirror X text offsets and portrait side if requested
    if mirror then
        dest.nameTextX  = -(dest.nameTextX  or 0)
        dest.hpTextX    = -(dest.hpTextX    or 0)
        dest.hpPctX     = -(dest.hpPctX     or 0)
        dest.levelTextX = -(dest.levelTextX or 0)
        -- Mirror name alignment: LEFT→RIGHT, RIGHT→LEFT
        if dest.nameAlign == "LEFT" then dest.nameAlign = "RIGHT"
        elseif dest.nameAlign == "RIGHT" then dest.nameAlign = "LEFT" end
        if dest.hpTextAlign == "LEFT" then dest.hpTextAlign = "RIGHT"
        elseif dest.hpTextAlign == "RIGHT" then dest.hpTextAlign = "LEFT" end
        if dest.levelTextAlign == "LEFT" then dest.levelTextAlign = "RIGHT"
        elseif dest.levelTextAlign == "RIGHT" then dest.levelTextAlign = "LEFT" end
        -- Mirror portrait: flip side and negate custom X offset
        if dest.portraitSide == "Left" then dest.portraitSide = "Right"
        elseif dest.portraitSide == "Right" then dest.portraitSide = "Left" end
        dest.portraitX = -(dest.portraitX or 0)
        -- Mirror aura Grow X: LEFT↔RIGHT for both buffs and debuffs
        if dest.buffGrowX == "LEFT" then dest.buffGrowX = "RIGHT"
        elseif dest.buffGrowX == "RIGHT" then dest.buffGrowX = "LEFT" end
        if dest.debuffGrowX == "LEFT" then dest.debuffGrowX = "RIGHT"
        elseif dest.debuffGrowX == "RIGHT" then dest.debuffGrowX = "LEFT" end
    end
    UnitFramesLite_UpdateFrame(destUnit)
    UnitFramesLite_UpdateAuras(destUnit)
end

-- Profiles -------------------------------------------------------------------

-- Deep copy all keys (including nested tables of any depth)
local function GetProfiles()
    UnitFramesLiteDB.profiles = UnitFramesLiteDB.profiles or { active = "Default", list = {} }
    return UnitFramesLiteDB.profiles
end

-- Capture current per-unit settings into a snapshot table
local function SnapshotUnits()
    local snap = {}
    for unit in pairs(defaults) do
        snap[unit] = DeepCopyAllDB(UnitFramesLiteDB[unit] or {})
    end
    return snap
end

function UnitFramesLite_ProfileList()
    local p = GetProfiles(); local names = {}
    for name in pairs(p.list) do names[#names+1] = name end
    table.sort(names); return names
end

function UnitFramesLite_ProfileCreate(name)
    if not name or name == "" then return end
    local p = GetProfiles()
    p.list[name] = SnapshotUnits()
    p.active = name
end

function UnitFramesLite_ProfileSetDefault(name)
    local p = GetProfiles()
    if not p.list[name] then return end
    p.active = name
    -- Apply the saved profile to the live DB
    local snap = p.list[name]
    for unit in pairs(defaults) do
        if snap[unit] then
            UnitFramesLiteDB[unit] = DeepCopyAllDB(snap[unit])
            CopyDefaults(defaults[unit], UnitFramesLiteDB[unit])
            UnitFramesLite_UpdateFrame(unit)
        end
    end
end

function UnitFramesLite_ProfileCopyFrom(name)
    -- Same as SetDefault but without changing active profile name
    local p = GetProfiles()
    if not p.list[name] then return end
    local snap = p.list[name]
    for unit in pairs(defaults) do
        if snap[unit] then
            UnitFramesLiteDB[unit] = DeepCopyAllDB(snap[unit])
            CopyDefaults(defaults[unit], UnitFramesLiteDB[unit])
            UnitFramesLite_UpdateFrame(unit)
        end
    end
end

function UnitFramesLite_ProfileDelete(name)
    local p = GetProfiles()
    p.list[name] = nil
    if p.active == name then p.active = "Default" end
end

-- Blizzard frame visibility --------------------------------------------------


-- Controls visibility and alpha of the custom UFL resource bar only.
-- The Blizzard resource bar is left completely untouched — use WoW Edit Mode for that.
function UnitFramesLite_UpdateResourceVisibility()
    local db = GetDB("player")
    local inCombat  = UnitAffectingCombat("player")
    local hasTarget = UnitExists("target")
    local alpha     = db.resourceAlpha or 1.0

    -- Custom bar is always shown in combat.
    -- "Show out of combat" controls out-of-combat visibility.
    -- "Show when target selected" shows it whenever a target exists regardless of combat state.
    local showOutCombat  = db.resourceShowOutCombat ~= false  -- default true
    local showWithTarget = db.resourceShowWithTarget or false

    local cfg = resourceClass and CLASS_RESOURCES[resourceClass]
    local shouldShow = true
    if testResourceActive then
        shouldShow = true
    elseif db.showResources == false then
        shouldShow = false
    elseif IsResourceGated(cfg) then
        shouldShow = false
    elseif inCombat then
        shouldShow = true
    elseif showWithTarget and hasTarget and (UnitReaction("target", "player") or 4) <= 3 then
        shouldShow = true
    else
        shouldShow = showOutCombat
    end

    if resourceFrame then
        if shouldShow then
            resourceFrame:SetAlpha(alpha)
            UnitFramesLite_UpdateResourceLayout()
        else
            resourceFrame:SetAlpha(0)
        end
    end
end

-- Blizzard frame names per setting key.  Each group includes the primary frame
-- and all linked/child frames that should hide along with it.
-- Frames hidden via alpha=0 + mouse disabled.  These are frames Blizzard leaves
-- shown persistently, so SetAlpha is stable.  Restoring is SetAlpha + EnableMouse.
local BLIZZ_FRAMES = {
    hideBlizzPlayer    = {"PlayerFrame", "PlayerFrameAlternateManaBar"},
    hideBlizzTarget    = {"TargetFrame"},
    hideBlizzTargetToT = {"TargetFrameToT"},
    hideBlizzFocus     = {"FocusFrame"},
    hideBlizzFocusToT  = {"FocusFrameToT"},
    hideBlizzPet       = {"PetFrame"},
    hideBlizzPetTarget = {"PetFrameToT"},
}


local blizzSavedAlpha    = {}  -- [frameName] = original alpha

function UnitFramesLite_ApplyBlizzardFrames()
    local g = UnitFramesLiteDB and UnitFramesLiteDB.global
    if not g then return end

    -- Persistent frames: alpha approach
    for key, frameNames in pairs(BLIZZ_FRAMES) do
        local hide = g[key]
        for _, name in ipairs(frameNames) do
            local f = _G[name]
            if f then
                if hide then
                    if blizzSavedAlpha[name] == nil then
                        blizzSavedAlpha[name] = f:GetAlpha()
                    end
                    f:SetAlpha(0)
                    f:EnableMouse(false)
                else
                    f:SetAlpha(blizzSavedAlpha[name] or 1)
                    blizzSavedAlpha[name] = nil
                    f:EnableMouse(true)
                end
            end
        end
    end

end

-- Minimap button + Bazooka plugin (LibDataBroker / LibDBIcon) ----------------
-- One LDB launcher object serves both purposes:
--   • LibDBIcon-1.0  → minimap button (draggable, position saved in DB)
--   • Bazooka / any LDB display addon → broker bar plugin

local ldbObject  -- the shared LDB data object

local function SetupLDB()
    local LDB     = LibStub and LibStub("LibDataBroker-1.1", true)
    if not LDB then return end

    if ldbObject then return end  -- already created

    ldbObject = LDB:NewDataObject("UnitFramesLite", {
        type  = "launcher",
        label = "UnitFramesLite",
        icon  = "Interface\\Icons\\INV_Helmet_08",
        OnClick = function(_, button)
            if button == "LeftButton" then
                if UnitFramesLite_ShowOptions then UnitFramesLite_ShowOptions() end
            end
        end,
        OnEnter = function(self)
            GameTooltip:SetOwner(self, "ANCHOR_CURSOR")
            GameTooltip:AddLine("UnitFramesLite")
            GameTooltip:AddLine("|cffaaaaaa(Left-click) Open options|r")
            GameTooltip:Show()
        end,
        OnLeave = function() GameTooltip:Hide() end,
    })
end

function UFL.ApplyMinimapButton()
    local g = UnitFramesLiteDB and UnitFramesLiteDB.global
    if not g then return end

    local LDBIcon = LibStub and LibStub("LibDBIcon-1.0", true)
    if not LDBIcon then return end

    SetupLDB()
    if not ldbObject then return end

    -- minimapData is the saved-variable table LibDBIcon uses for position/hide state
    if not UnitFramesLiteDB.minimapButton then
        UnitFramesLiteDB.minimapButton = {}
    end
    LDBIcon:Register("UnitFramesLite", ldbObject, UnitFramesLiteDB.minimapButton)

    if g.showMinimapButton then
        LDBIcon:Show("UnitFramesLite")
    else
        LDBIcon:Hide("UnitFramesLite")
    end
end

function UFL.ApplyBazookaPlugin()
    local g = UnitFramesLiteDB and UnitFramesLiteDB.global
    if not g or not g.showBazookaPlugin then return end
    SetupLDB()  -- ensure the LDB object exists for display addons to pick up
end

-- Slash commands -------------------------------------------------------------

SLASH_UNITFRAMESLITE1 = "/ufl"
SLASH_UNITFRAMESLITE2 = "/unitframeslite"
SlashCmdList["UNITFRAMESLITE"] = function(msg)
    local cmd = (msg or ""):lower():match("^%s*(.-)%s*$")
    if cmd == "" or cmd == "options" or cmd == "opt" then
        if UnitFramesLite_ShowOptions then UnitFramesLite_ShowOptions()
        else print("UnitFramesLite: options not ready yet.") end
        return
    end
    if cmd == "reset" then
        UnitFramesLiteDB = {}
        for unit in pairs(defaults) do
            UnitFramesLiteDB[unit] = CopyDefaults(defaults[unit], {})
        end
        for unit in pairs(frames) do UnitFramesLite_UpdateFrame(unit) end
        print("UnitFramesLite: settings reset to defaults.")
        return
    end
    if cmd == "debug" then
        local db = GetDB("player")
        print("UFL debug: showHPPct=" .. tostring(db.showHPPct) .. " sphereMode=" .. tostring(db.sphereMode))
        local ok, pct = pcall(UnitHealthPercent, "player", true, CurveConstants and CurveConstants.ScaleTo100)
        print("UFL debug: UnitHealthPercent ok=" .. tostring(ok) .. " pct=" .. tostring(pct))
        local pctStr = GetHPPercentText(false, true, "player")
        print("UFL debug: GetHPPercentText=" .. tostring(pctStr))
        local f = frames and frames["player"]
        print("UFL debug: frames.player=" .. tostring(f ~= nil))
        if f then
            local hpPct = f.hpPctText
            print("UFL debug: hpPctText exists=" .. tostring(hpPct ~= nil)
                .. (hpPct and (" shown=" .. tostring(hpPct:IsShown()) .. " text=" .. tostring(hpPct:GetText())) or ""))
        end
        return
    end
    if cmd == "blizz" then
        local candidates = {
            "ComboPointPlayerFrame", "ComboFrame", "ComboPoints",
            "PlayerPowerBarAlt", "PlayerPowerBar",
            "ClassNameplateBar", "ClassNameplateManaBar",
            "NamePlatePlayerFrame",
        }
        print("UFL blizz frame scan:")
        for _, name in ipairs(candidates) do
            local f = _G[name]
            if f and type(f) == "table" and f.IsShown then
                print("  |cff00ff00FRAME|r " .. name
                    .. " shown=" .. tostring(f:IsShown())
                    .. " alpha=" .. tostring(f:GetAlpha()))
            elseif f then
                print("  |cffffff00TABLE|r " .. name .. " (not a frame)")
            else
                print("  |cffff4444NIL|r   " .. name)
            end
        end
        -- Scan PlayerFrame children for combo/resource related sub-frames
        print("UFL PlayerFrame children scan:")
        local pf = _G["PlayerFrame"]
        if pf and pf.GetChildren then
            for _, child in next, {pf:GetChildren()} do
                local n = child:GetName()
                if n then
                    print("  " .. n .. " shown=" .. tostring(child:IsShown()) .. " alpha=" .. tostring(child:GetAlpha()))
                end
            end
        end
        return
    end
    print("UnitFramesLite commands:  /ufl options  /ufl reset  /ufl debug  /ufl blizz")
end

-- Status flags ---------------------------------------------------------------

local CLASSIFICATION_LABELS = {
    worldboss = " [Boss]", rareelite = " [Rare Elite]",
    elite = " [Elite]",    rare      = " [Rare]",
}

local function BuildStatusText(unit)
    local parts = {}
    if unit == "target" or unit == "focus" then
        local label = CLASSIFICATION_LABELS[UnitClassification(unit)]
        if label then parts[#parts+1] = label end
    end
    if UnitIsGhost(unit)             then parts[#parts+1] = " [Ghost]"
    elseif UnitIsDead(unit)          then parts[#parts+1] = " [Dead]"
    elseif UnitAffectingCombat(unit) then parts[#parts+1] = " [Combat]" end
    return table.concat(parts)
end

-- Frame setup ----------------------------------------------------------------

-- Dynamically creates a display frame with the same structure as the XML frames.
-- Used for focus and pet (which are not declared in XML).
local function CreateUFLDisplayFrame(frameName, defX, defY)
    if _G[frameName] then return _G[frameName] end   -- already exists (XML)
    local f = CreateFrame("Button", frameName, UIParent)
    f:SetSize(160, 35)
    f:SetPoint("CENTER", UIParent, "CENTER", defX, defY)
    f:Hide()
    local bg = f:CreateTexture(frameName.."BG", "BACKGROUND")
    bg:SetAllPoints()
    bg:SetColorTexture(0, 0, 0, 0.35)
    f.bg = bg
    local hp = CreateFrame("StatusBar", frameName.."HP", f)
    hp:SetPoint("TOPLEFT", f, "TOPLEFT")
    hp:SetSize(160, 35)
    f.hp = hp
    local power = CreateFrame("StatusBar", frameName.."Power", f)
    power:SetPoint("BOTTOMLEFT", f, "BOTTOMLEFT")
    power:SetSize(160, 8)
    power:Hide()
    f.power = power
    _G[frameName] = f
    return f
end

local function SetupFrame(displayFrame, unit)
    if not displayFrame then return end
    frames[unit] = displayFrame


    displayFrame:SetMovable(true)
    displayFrame:EnableMouse(true)
    displayFrame:RegisterForDrag("LeftButton")
    -- Pass right-click through so camera rotation works when the cursor is over the frame
    displayFrame:SetPropagateMouseClicks(true)
    displayFrame:SetScript("OnDragStart", function(self)
        if not GetDB(unit).locked then self:StartMoving() end
    end)
    displayFrame:SetScript("OnDragStop", function(self)
        self:StopMovingOrSizing()
        local cx, cy = self:GetCenter()
        local px, py = UIParent:GetCenter()
        if cx and cy and px and py then
            local db = GetDB(unit)
            db.x = math.floor(cx - px + 0.5)
            db.y = math.floor(cy - py + 0.5)
            self:ClearAllPoints()
            self:SetPoint("CENTER", UIParent, "CENTER", db.x, db.y)
        end
    end)

    if displayFrame.hp    then displayFrame.hp:SetFrameStrata("LOW")    end
    if displayFrame.power then displayFrame.power:SetFrameStrata("LOW") end

    local parentLevel = displayFrame:GetFrameLevel()
    local borderFrame = CreateFrame("Frame", nil, displayFrame, "BackdropTemplate")
    borderFrame:SetAllPoints()
    borderFrame:SetFrameLevel(parentLevel + 5)
    borderFrame:EnableMouse(false)
    borderFrame:Hide()
    displayFrame.borderFrame = borderFrame

    local textOverlay = CreateFrame("Frame", nil, displayFrame)
    textOverlay:SetAllPoints()
    textOverlay:SetFrameStrata("MEDIUM")
    textOverlay:SetFrameLevel(parentLevel + 20)  -- above orb (+3), border (+5), orbPowerBar (+6)
    textOverlay:EnableMouse(false)
    displayFrame.textOverlay = textOverlay

    displayFrame.nameText   = textOverlay:CreateFontString(nil, "OVERLAY", "GameFontNormal")
    displayFrame.hpText     = textOverlay:CreateFontString(nil, "OVERLAY", "GameFontNormal")
    displayFrame.hpPctText  = textOverlay:CreateFontString(nil, "OVERLAY", "GameFontNormal")
    displayFrame.levelText  = textOverlay:CreateFontString(nil, "OVERLAY", "GameFontNormal")

    displayFrame:HookScript("OnHide", function() textOverlay:Hide() end)
    displayFrame:HookScript("OnShow", function() textOverlay:Show() end)

    -- ── Portrait ──────────────────────────────────────────────────────────
    -- portraitFrame holds either a 2D texture or a 3D model.
    -- Parented to UIParent so it sits beside (not inside) the unit frame.
    local portraitFrame = CreateFrame("Frame", nil, UIParent)
    portraitFrame:Hide()
    portraitFrame:SetFrameLevel(displayFrame:GetFrameLevel() + 1)
    portraitFrame:EnableMouse(false)
    displayFrame.portraitFrame = portraitFrame

    -- 2D portrait texture (used for "2D" mode)
    local portrait2D = portraitFrame:CreateTexture(nil, "ARTWORK")
    portrait2D:SetAllPoints()
    displayFrame.portrait2D = portrait2D

    -- 3D portrait model (used for "3D" and "Unit Type" modes)
    local portrait3D = CreateFrame("PlayerModel", nil, portraitFrame)
    portrait3D:SetAllPoints()
    portrait3D:Hide()
    displayFrame.portrait3D = portrait3D

    -- ── Power ring (behind orb) ───────────────────────────────────────────
    local powerRingFrame = CreateFrame("Frame", nil, displayFrame)
    powerRingFrame:Hide()
    powerRingFrame:EnableMouse(false)
    displayFrame.powerRingFrame = powerRingFrame

    local powerRingBg = powerRingFrame:CreateTexture(nil, "BACKGROUND")
    powerRingBg:SetAllPoints()
    displayFrame.powerRingBg = powerRingBg

    local powerRingCircMask = powerRingFrame:CreateMaskTexture()
    powerRingCircMask:SetTexture(ORB_MASK, "CLAMPTOBLACKADDITIVE", "CLAMPTOBLACKADDITIVE")
    powerRingCircMask:SetAllPoints()
    powerRingBg:AddMaskTexture(powerRingCircMask)
    displayFrame.powerRingCircMask = powerRingCircMask

    -- Centre cover: sits above powerRingBg (BORDER layer) on the same frame, sized to
    -- the orb diameter and masked to a circle. Always coloured with orbBgColor so the
    -- ring BG colour only shows in the ring band, not the orb centre.
    local powerRingCentreCover = powerRingFrame:CreateTexture(nil, "BORDER")
    powerRingCentreCover:SetPoint("CENTER", powerRingFrame, "CENTER", 0, 0)
    displayFrame.powerRingCentreCover = powerRingCentreCover

    local powerRingCentreMask = powerRingFrame:CreateMaskTexture()
    powerRingCentreMask:SetTexture(ORB_MASK, "CLAMPTOBLACKADDITIVE", "CLAMPTOBLACKADDITIVE")
    powerRingCentreCover:AddMaskTexture(powerRingCentreMask)
    displayFrame.powerRingCentreMask = powerRingCentreMask

    -- Radial sweep via Cooldown frame. SetCooldown(start, duration) is a C-function
    -- that accepts secret numbers directly as arguments — no Lua arithmetic needed.
    -- We pass: start = GetTime() - power,  duration = maxPower
    -- so elapsed/duration = power/maxPower = fill fraction.
    -- Right half: fills the 3-o'clock side of the ring (CW: second 50%; CCW: first 50%)
    local prFillR = CreateFrame("StatusBar", nil, powerRingFrame)
    prFillR:SetStatusBarTexture("Interface\\Buttons\\WHITE8X8")
    prFillR:EnableMouse(false)
    displayFrame.powerRingFillR = prFillR
    local prStR = prFillR:GetStatusBarTexture()
    if prStR then prStR:AddMaskTexture(powerRingCircMask) end

    -- Left half: fills the 9-o'clock side (CW: first 50%; CCW: second 50%)
    local prFillL = CreateFrame("StatusBar", nil, powerRingFrame)
    prFillL:SetStatusBarTexture("Interface\\Buttons\\WHITE8X8")
    prFillL:EnableMouse(false)
    displayFrame.powerRingFillL = prFillL
    local prStL = prFillL:GetStatusBarTexture()
    if prStL then prStL:AddMaskTexture(powerRingCircMask) end

    -- ── Orb power bar (standalone bar, shown when orbPowerMode=="Bar") ─────
    local orbPowerBar = CreateFrame("StatusBar", nil, displayFrame)
    orbPowerBar:SetStatusBarTexture("Interface\\Buttons\\WHITE8X8")
    orbPowerBar:SetFrameStrata("MEDIUM")
    orbPowerBar:SetFrameLevel(parentLevel + 6)
    orbPowerBar:EnableMouse(false)
    orbPowerBar:Hide()
    displayFrame.orbPowerBar = orbPowerBar
    local orbPowerBarBg = orbPowerBar:CreateTexture(nil, "BACKGROUND")
    orbPowerBarBg:SetAllPoints()
    displayFrame.orbPowerBarBg = orbPowerBarBg

    -- ── Orb inner border (between power ring fills and health orb) ───────
    -- Uses a donut TGA with a real alpha-channel hole so the background shows
    -- through the centre rather than being covered by a solid disc.
    local orbBorderFrame = CreateFrame("Frame", nil, displayFrame)
    orbBorderFrame:Hide()
    orbBorderFrame:SetFrameLevel(powerRingFrame:GetFrameLevel() + 2)
    orbBorderFrame:EnableMouse(false)
    displayFrame.orbBorderFrame = orbBorderFrame

    local orbBorderTex = orbBorderFrame:CreateTexture(nil, "BACKGROUND")
    orbBorderTex:SetAllPoints()
    orbBorderTex:SetBlendMode("BLEND")
    displayFrame.orbBorderTex = orbBorderTex

    -- ── Orb (above power ring and inner border) ───────────────────────────
    local orbFrame = CreateFrame("Frame", nil, displayFrame)
    orbFrame:Hide()
    orbFrame:SetFrameLevel(powerRingFrame:GetFrameLevel() + 3)
    orbFrame:EnableMouse(false)
    displayFrame.orbFrame = orbFrame

    local orbBg = orbFrame:CreateTexture(nil, "BACKGROUND")
    orbBg:SetAllPoints()
    displayFrame.orbBg = orbBg

    local orbCircleMask = orbFrame:CreateMaskTexture()
    orbCircleMask:SetTexture(ORB_MASK, "CLAMPTOBLACKADDITIVE", "CLAMPTOBLACKADDITIVE")
    orbCircleMask:SetAllPoints()
    orbBg:AddMaskTexture(orbCircleMask)
    displayFrame.orbCircleMask = orbCircleMask

    local orbFill = CreateFrame("StatusBar", nil, orbFrame)
    orbFill:SetAllPoints()
    orbFill:SetStatusBarTexture("Interface\\Buttons\\WHITE8X8")
    orbFill:EnableMouse(false)
    displayFrame.orbFill = orbFill
    local st = orbFill:GetStatusBarTexture()
    if st then st:AddMaskTexture(orbCircleMask) end

    local orbFill2 = CreateFrame("StatusBar", nil, orbFrame)
    orbFill2:SetStatusBarTexture("Interface\\Buttons\\WHITE8X8")
    orbFill2:EnableMouse(false)
    orbFill2:Hide()
    displayFrame.orbFill2 = orbFill2
    local st2 = orbFill2:GetStatusBarTexture()
    if st2 then st2:AddMaskTexture(orbCircleMask) end

    -- ── Elite / rare-elite dragon border ──────────────────────────────────
    -- Parented to UIParent so the texture can be sized larger than the unit frame.
    -- Only meaningful for target and focus; hidden for player/pet via UpdateEliteBorder.
    local eliteBorderFrame = CreateFrame("Frame", nil, UIParent)
    eliteBorderFrame:Hide()
    eliteBorderFrame:EnableMouse(false)
    eliteBorderFrame:SetFrameLevel(displayFrame:GetFrameLevel() + 25)
    local eliteBorderTex = eliteBorderFrame:CreateTexture(nil, "OVERLAY")
    eliteBorderTex:SetAllPoints()
    displayFrame.eliteBorderFrame = eliteBorderFrame
    displayFrame.eliteBorderTex   = eliteBorderTex

    -- Hide the elite border when the unit frame is hidden/shown
    displayFrame:HookScript("OnHide", function() eliteBorderFrame:Hide() end)

    -- ── Event listener ────────────────────────────────────────────────────
    local listener = CreateFrame("Frame")
    listener:RegisterUnitEvent("UNIT_HEALTH",          unit)
    listener:RegisterUnitEvent("UNIT_MAXHEALTH",       unit)
    listener:RegisterUnitEvent("UNIT_NAME_UPDATE",     unit)
    listener:RegisterUnitEvent("UNIT_FLAGS",           unit)
    listener:RegisterUnitEvent("UNIT_FACTION",         unit)
    listener:RegisterUnitEvent("UNIT_LEVEL",           unit)
    listener:RegisterUnitEvent("UNIT_POWER_UPDATE",    unit)
    listener:RegisterUnitEvent("UNIT_POWER_FREQUENT",  unit)
    listener:RegisterUnitEvent("UNIT_DISPLAYPOWER",    unit)
    listener:RegisterUnitEvent("UNIT_PORTRAIT_UPDATE", unit)
    listener:RegisterUnitEvent("UNIT_MODEL_CHANGED",   unit)
    listener:RegisterUnitEvent("UNIT_AURA",            unit)
    if unit == "target" then listener:RegisterEvent("PLAYER_TARGET_CHANGED") end
    if unit == "focus"  then listener:RegisterEvent("PLAYER_FOCUS_CHANGED")  end
    if unit == "pet"    then listener:RegisterEvent("UNIT_PET")               end

    local function Update()
        local hp       = UnitHealth(unit)
        local maxhp    = UnitHealthMax(unit)
        local power    = UnitPower(unit)
        local maxPower = UnitPowerMax(unit)
        local name     = UnitName(unit) or unit
        local isDead   = UnitIsDead(unit)
        local isTapped = UnitIsTapDenied(unit)
        local useGrey  = isDead or isTapped
        local db       = GetDB(unit)

        displayFrame.hp:SetMinMaxValues(0, maxhp)
        displayFrame.hp:SetValue(isDead and 0 or hp)

        if displayFrame.orbFill then
            if db.sphereMode and db.orbGradientDir == "CENTRE"
               and displayFrame.orbFill2 and displayFrame.orbFill2:IsShown() then
                -- CENTRE gradient: lower half is 0→halfMax, upper half is halfMax→max.
                -- Encode the split into SetMinMaxValues so WoW handles the secret-number
                -- arithmetic internally — no Lua division of secret numbers needed.
                local halfMax = 0
                pcall(function() halfMax = maxhp / 2 end)
                local v = isDead and 0 or hp
                displayFrame.orbFill:SetMinMaxValues(0, halfMax)
                displayFrame.orbFill:SetValue(v)
                displayFrame.orbFill2:SetMinMaxValues(halfMax, maxhp)
                displayFrame.orbFill2:SetValue(v)
            else
                displayFrame.orbFill:SetMinMaxValues(0, maxhp)
                displayFrame.orbFill:SetValue(isDead and 0 or hp)
                if displayFrame.orbFill2 then
                    displayFrame.orbFill2:SetMinMaxValues(0, maxhp)
                    displayFrame.orbFill2:SetValue(isDead and 0 or hp)
                end
            end
        end

        -- Power bar
        if displayFrame.power then
            displayFrame.power:SetMinMaxValues(0, maxPower)
            displayFrame.power:SetValue(isDead and 0 or power)
            UpdatePowerColor(displayFrame, unit)
        end

        -- Power ring — power values are secret numbers in WoW 12.x.
        -- Avoid all Lua comparison/arithmetic on secret values; instead encode
        -- the half-ring split directly into SetMinMaxValues so WoW handles the
        -- math internally.  All arithmetic on secret numbers stays inside pcall.
        --
        -- CW ring visual: left half fills 0-50% of ring (power 0→max/2),
        --                 right half fills 50-100% (power max/2→max).
        -- Achieved by:   left  → SetMinMaxValues(0, halfMax),  SetValue(power)
        --                right → SetMinMaxValues(halfMax, max), SetValue(power)
        -- SetMinMaxValues and SetValue accept secret numbers just like StatusBar
        -- hp/power bars do — no taint error.
        local pMode = db.orbPowerMode or "None"
        if pMode == "Ring" and displayFrame.powerRingFillR and displayFrame.powerRingFillL then
            local ccw   = db.orbPowerRingCCW or false
            local fillR = displayFrame.powerRingFillR
            local fillL = displayFrame.powerRingFillL
            local halfMax = 0
            pcall(function() halfMax = maxPower / 2 end)
            if not ccw then
                fillL:SetMinMaxValues(0, halfMax)
                fillL:SetValue(isDead and 0 or power)
                fillR:SetMinMaxValues(halfMax, maxPower)
                fillR:SetValue(isDead and 0 or power)
            else
                fillR:SetMinMaxValues(0, halfMax)
                fillR:SetValue(isDead and 0 or power)
                fillL:SetMinMaxValues(halfMax, maxPower)
                fillL:SetValue(isDead and 0 or power)
            end
            ApplyPowerRingColor(displayFrame, unit)
        end
        if pMode == "Bar" and displayFrame.orbPowerBar then
            displayFrame.orbPowerBar:SetMinMaxValues(0, maxPower)
            displayFrame.orbPowerBar:SetValue(isDead and 0 or power)
        end

        -- Name
        if db.showName ~= false then
            if displayFrame.nameText then
                displayFrame.nameText:SetText(name)
                if useGrey then
                    displayFrame.nameText:SetTextColor(DEAD_COLOR[1], DEAD_COLOR[2], DEAD_COLOR[3], DEAD_COLOR[4])
                else
                    local c = (db.nameColorByReaction and GetReactionColor(unit, db)) or db.nameColor or {1,1,1,1}
                    displayFrame.nameText:SetTextColor(c[1], c[2], c[3], c[4])
                end
                displayFrame.nameText:Show()
            end
        else
            if displayFrame.nameText then displayFrame.nameText:Hide() end
        end

        -- HP text
        -- IMPORTANT: GetHealthText may return a secret string.
        -- We check hpStr ~= nil (type comparison, safe) rather than comparing
        -- the string value itself, to avoid the "attempt to compare secret string" error.
        if displayFrame.hpText then
            if db.showHPText ~= false then
                local hpStr   = GetHealthText(hp, maxhp, isDead, db.hpContent, db.hpFormat)
                local statStr = db.sphereMode and "" or BuildStatusText(unit)
                -- statStr is always a plain string (our own literals), safe to compare.
                if hpStr ~= nil or statStr ~= "" then
                    displayFrame.hpText:SetText((hpStr or "") .. statStr)
                    if useGrey then
                        displayFrame.hpText:SetTextColor(DEAD_COLOR[1], DEAD_COLOR[2], DEAD_COLOR[3], DEAD_COLOR[4])
                    else
                        local c = (db.hpTextColorByReaction and GetReactionColor(unit, db)) or db.hpTextColor or {1,1,1,1}
                        displayFrame.hpText:SetTextColor(c[1], c[2], c[3], c[4])
                    end
                    displayFrame.hpText:Show()
                else
                    displayFrame.hpText:Hide()
                end
            else
                displayFrame.hpText:Hide()
            end
        end

        -- HP Percent text (independent of HP text)
        if displayFrame.hpPctText then
            if db.showHPPct then
                local pctStr = GetHPPercentText(isDead, db.hpPctShowSymbol ~= false, unit)
                if pctStr ~= nil then
                    displayFrame.hpPctText:SetText(pctStr)
                    displayFrame.hpPctText:Show()
                else
                    displayFrame.hpPctText:Hide()
                end
            else
                displayFrame.hpPctText:Hide()
            end
        end

        -- Level (no "L" prefix)
        if displayFrame.levelText then
            if db.showLevel ~= false and UnitExists(unit) then
                local level = UnitLevel(unit)
                if level and level > 0 then
                    displayFrame.levelText:SetText(tostring(level))
                    displayFrame.levelText:Show()
                elseif level == -1 then
                    displayFrame.levelText:SetText("??")
                    displayFrame.levelText:Show()
                else
                    displayFrame.levelText:Hide()
                end
                if displayFrame.levelText:IsShown() then
                    if useGrey then
                        displayFrame.levelText:SetTextColor(DEAD_COLOR[1], DEAD_COLOR[2], DEAD_COLOR[3], DEAD_COLOR[4])
                    else
                        local c = (db.levelColorByReaction and GetReactionColor(unit, db)) or db.levelColor or {1,1,1,1}
                        displayFrame.levelText:SetTextColor(c[1], c[2], c[3], c[4])
                    end
                end
            else
                displayFrame.levelText:Hide()
            end
        end

        -- Portrait texture/model refresh (only if portrait is shown)
        if displayFrame.portraitFrame and displayFrame.portraitFrame:IsShown() then
            local pMode = db.portraitMode or "None"
            if pMode == "2D" and displayFrame.portrait2D then
                SetPortraitTexture(displayFrame.portrait2D, unit)
            elseif (pMode == "3D" or pMode == "Unit Type") and displayFrame.portrait3D then
                displayFrame.portrait3D:SetUnit(unit)
            end
        end
    end

    listener:SetScript("OnEvent", function(_, evt)
        Update()
        if evt == "UNIT_AURA" then UnitFramesLite_UpdateAuras(unit) end
        -- UNIT_FLAGS fires when unit classification changes (elite → normal, etc.)
        if evt == "UNIT_FLAGS" then UnitFramesLite_UpdateEliteBorder(unit) end
        -- Refresh frame (including reaction-based text colours) on target/unit change
        if evt == "PLAYER_TARGET_CHANGED" or evt == "PLAYER_FOCUS_CHANGED"
           or evt == "UNIT_PET" or evt == "UNIT_FACTION" then
            UnitFramesLite_UpdateFrame(unit)
            -- If the target's faction changed, also refresh player alpha (fadeHostileTarget)
            if evt == "UNIT_FACTION" and unit == "target" then
                UnitFramesLite_UpdateAlpha("player")
            end
        end
    end)
    displayFrame.OnUFLUpdate = Update

    -- Orb HP% text: poll UnitHealthPercent on a throttle so the text stays in sync
    -- with the fill without waiting for UNIT_HEALTH events. CurveConstants.ScaleTo100
    -- returns a plain integer, avoiding all secret-number arithmetic.
    local orbPctElapsed = 0
    orbFill:SetScript("OnUpdate", function(self, elapsed)
        orbPctElapsed = orbPctElapsed + elapsed
        if orbPctElapsed < 0.05 then return end  -- ~20 Hz
        orbPctElapsed = 0
        local db = GetDB(unit)
        if not (db.sphereMode and db.showHPPct) then return end
        local hpPctText = displayFrame.hpPctText
        if not hpPctText or not hpPctText:IsShown() then return end
        local pctStr = GetHPPercentText(UnitIsDead(unit), db.hpPctShowSymbol ~= false, unit)
        if pctStr then hpPctText:SetText(pctStr) end
    end)
end

-- Aura display --------------------------------------------------------------
-- Separate containers for buffs and debuffs per unit.
-- Layout and filtering are recomputed on every UNIT_AURA event.

-- auraFrames[unit] = { buff = {container, pool={}}, debuff = {container, pool={}} }
-- (auraFrames is forward-declared near the top of the file)

local DISPEL_TYPES = { Magic=true, Curse=true, Disease=true, Poison=true }

local function GetAuraData(unit)
    if auraFrames[unit] then return auraFrames[unit] end
    local function makeSlot(suffix)
        local c = CreateFrame("Frame", "UFL_Auras_" .. unit .. "_" .. suffix, UIParent)
        c:SetSize(1, 1); c:Hide()
        return { container = c }
    end
    auraFrames[unit] = { buff = makeSlot("buff"), debuff = makeSlot("debuff") }
    return auraFrames[unit]
end

-- Keep old name for event-init call compatibility
local function GetAuraContainer(unit) return GetAuraData(unit) end

local function GetOrCreateIcon(pool, idx, container, prefix)
    if pool[idx] then return pool[idx] end
    local btn = CreateFrame("Button", nil, container)
    btn:SetSize(24, 24)
    local icon = btn:CreateTexture(nil, "BACKGROUND", nil, 1)
    icon:SetAllPoints()
    icon:SetTexCoord(0.08, 0.92, 0.08, 0.92)
    btn.icon = icon
    local border = btn:CreateTexture(nil, "BACKGROUND")
    border:SetAllPoints()
    border:SetColorTexture(0, 0, 0, 1)
    btn.border = border
    local cd = CreateFrame("Cooldown", nil, btn, "CooldownFrameTemplate")
    cd:SetAllPoints(); cd:SetDrawEdge(false); cd:SetDrawSwipe(true); cd:SetHideCountdownNumbers(true)
    cd:SetReverse(true)
    btn.cd = cd

    -- Register with Masque if available.  Pass only the regions that exist on
    -- these simple icon buttons; set everything else to false so Masque won't
    -- try to skin regions that aren't there.
    if prefix then
        local grp = GetMSQGroup(prefix)
        if grp then
            grp:AddButton(btn, {
                Icon      = btn.icon,
                Cooldown  = btn.cd,
                Normal    = false,
                Pushed    = false,
                Disabled  = false,
                Checked   = false,
                Highlight = false,
                Flash     = false,
                Border    = btn.border,
                Backdrop  = false,
                Gloss     = false,
                Shadow    = false,
            })
        end
    end
    -- Custom timer FontString — gives full control over font and colour.
    local timerFS = btn:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
    timerFS:SetPoint("BOTTOM", btn, "BOTTOM", 0, 1)
    timerFS:SetJustifyH("CENTER")
    timerFS:SetText("")
    btn.timerFS = timerFS
    local stack = btn:CreateFontString(nil, "OVERLAY", "NumberFontNormal")
    stack:SetPoint("BOTTOMRIGHT", btn, "BOTTOMRIGHT", 2, 0)
    btn.stack = stack
    local debuffBorder = btn:CreateTexture(nil, "OVERLAY")
    debuffBorder:SetTexture("Interface\\Buttons\\UI-Debuff-Overlays")
    debuffBorder:SetTexCoord(0.296875, 0.5703125, 0, 0.515625)
    debuffBorder:SetAllPoints(); debuffBorder:Hide()
    btn.debuffBorder = debuffBorder

    -- Tooltip: btn.auraUnit and btn.auraIndex are set by LayoutAuraStrip before Show()
    local tooltipTimer = nil
    btn:SetScript("OnEnter", function(self)
        local db = self.auraUnit and GetDB(self.auraUnit)
        if not db then return end
        local pfx   = (self.auraFilter == "HELPFUL") and "buff" or "debuff"
        if db[pfx.."TooltipEnabled"] == false then return end
        local delay = db[pfx.."TooltipDelay"] or 0
        local function showTip()
            tooltipTimer = nil
            if not self:IsMouseOver() then return end
            GameTooltip:SetOwner(self, "ANCHOR_BOTTOMLEFT")
            if self.auraUnit and self.auraIndex and self.auraFilter then
                GameTooltip:SetUnitAura(self.auraUnit, self.auraIndex, self.auraFilter)
            end
            GameTooltip:Show()
        end
        if delay <= 0 then
            showTip()
        else
            tooltipTimer = C_Timer.After(delay, showTip)
        end
    end)
    btn:SetScript("OnLeave", function()
        tooltipTimer = nil
        GameTooltip:Hide()
    end)

    pool[idx] = btn
    return btn
end

local DEBUFF_COLORS = {
    Magic   = {0.2, 0.6, 1},
    Curse   = {0.6, 0,   1},
    Disease = {0.6, 0.4, 0},
    Poison  = {0,   0.6, 0},
}

-- Returns how far above/below the frame centre the outermost visual edge extends.
-- In orb mode this is the orb radius + power ring thickness (if shown).
-- In bar mode it's just half the frame height.
local function GetFrameVerticalExtent(frame, db)
    if db.sphereMode then
        local sz    = math.max(20, db.sphereSize or 80)
        local extra = 0
        local pMode = db.orbPowerMode or "None"
        if pMode == "Ring" then
            extra = math.max(4, db.orbPowerRingThickness or 8)
        end
        return sz / 2 + extra
    else
        return (db.frameHeight or 35) / 2
    end
end

-- Format a remaining-duration value (seconds) as a short timer string.
-- Apply the cooldown swipe to a Cooldown frame for an aura.
-- Tries GetAuraDuration first (handles secret numbers on real enemy auras).
-- Falls back to plain SetCooldown arithmetic for test auras or friendly auras
-- whose plain-number fields are directly usable.
local function SetAuraCooldown(cd, unit, aura)
    local durObj = C_UnitAuras.GetAuraDuration(unit, aura.auraInstanceID)
    if durObj then
        cd:SetCooldownFromDurationObject(durObj)
        return
    end
    -- durObj is nil: either permanent aura, or test aura with plain numbers.
    -- Try plain arithmetic in pcall — succeeds for test auras; no-ops if secret.
    local set = false
    pcall(function()
        if aura.duration and aura.duration > 0 and aura.expirationTime and aura.expirationTime > 0 then
            cd:SetCooldown(aura.expirationTime - aura.duration, aura.duration)
            set = true
        end
    end)
    if not set then
        cd:SetCooldown(0, 0)
    end
end

-- All arithmetic is via pcall because expirationTime may be a secret number.
local function FormatAuraTimer(aura)
    local remaining = 0
    local ok = pcall(function()
        if aura.expirationTime and aura.expirationTime > 0 then
            remaining = aura.expirationTime - GetTime()
        end
    end)
    if not ok or remaining <= 0 then return "" end
    if remaining >= 3600 then
        return string.format("%dh", math.floor(remaining / 3600))
    elseif remaining >= 60 then
        return string.format("%dm", math.floor(remaining / 60))
    else
        return string.format("%d", math.ceil(remaining))
    end
end

-- Apply font, size, and colour to a FontString used for aura timer display.
local function ApplyTimerStyle(fs, fontName, fontSize, color)
    local path = nil
    if fontName and LSM then
        path = LSM:Fetch("font", fontName)
    end
    local sz = fontSize or 10
    if path then
        fs:SetFont(path, sz, "OUTLINE")
    else
        local existingPath, _, flags = fs:GetFont()
        if existingPath then
            fs:SetFont(existingPath, sz, flags or "OUTLINE")
        end
    end
    if color then
        fs:SetTextColor(color[1], color[2], color[3], color[4] or 1)
    end
end

-- Hide every item in every mode-specific pool for a slot (called on mode switch).
local function HideAllPools(slot)
    for _, pool in ipairs({ slot.iconPool or {}, slot.barPool or {}, slot.ringPool or {} }) do
        for i = 1, #pool do pool[i]:Hide() end
    end
end

-- Lay out one aura strip (buffs or debuffs) given collected aura list + config.
local function LayoutAuraStrip(slot, auras, frame, db, iconSize, perRow, maxShown,
                                growX, growY, xOffset, yOffset, anchorToFrame, extraVertPad,
                                unit, auraFilter, prefix)
    slot.iconPool = slot.iconPool or {}
    -- Hide other-mode pools so stale frames don't show through
    for _, p in ipairs({ slot.barPool or {}, slot.ringPool or {} }) do
        for i = 1, #p do p[i]:Hide() end
    end
    local container = slot.container
    local pool      = slot.iconPool
    local gap       = 2

    -- Clamp to maxShown
    local count = math.min(#auras, maxShown)

    if count == 0 then
        container:Hide()
        for i = 1, #pool do pool[i]:Hide() end
        return
    end

    local cols  = math.max(1, perRow)
    local rows  = math.ceil(count / cols)
    local totalW = cols * (iconSize + gap) - gap
    local totalH = rows * (iconSize + gap) - gap

    -- For debuffs growing UP: container TOPLEFT is the top-left of the bottom row.
    -- Icon[1] should be centred on the orb, so shift container left by half its width
    -- minus half an icon (so icon[1] centre = frame centre).
    -- growX=LEFT: icon[1] is placed at container RIGHT edge going left →
    --   icon[1] right edge = container TOPLEFT.x + totalW - 0 = container right.
    --   icon[1] centre.x   = container right - iconSize/2
    --   we want icon[1] centre.x = frame centre.x → xOffset = -(totalW - iconSize/2)
    -- growX=RIGHT: icon[1] left = 0 → centre = iconSize/2 → xOffset = -iconSize/2
    -- This is automatically handled by the container anchor xOffset: caller passes 0 for centred.

    container:SetSize(math.max(1, totalW), math.max(1, totalH))
    container:ClearAllPoints()

    if anchorToFrame and frame then
        -- Vertical padding: account for orb/ring extending beyond the frame rect
        local vertExtent = GetFrameVerticalExtent(frame, db)
        local frameH     = (db.frameHeight or 35)
        local pad        = math.max(0, vertExtent - frameH / 2) + extraVertPad + 2

        -- Natural horizontal base for icon[1]:
        --   Orb mode  → icon[1] centred on orb centre → baseX = 0
        --   Bar mode  → icon[1] at the near edge of the health bar:
        --               growX=LEFT  → start at right edge → baseX = +frameWidth/2
        --               growX=RIGHT → start at left edge  → baseX = -frameWidth/2
        local baseX
        if db.sphereMode then
            baseX = 0
        else
            local halfW = (db.frameWidth or 160) / 2
            baseX = (growX == "LEFT") and halfW or -halfW
        end

        -- cxOffset positions the container so icon[1]'s centre lands at baseX + xOffset.
        -- icon[1] centre within container:
        --   growX=LEFT  → icon[1] is the rightmost icon in row 1 → its centre x = totalW - iconSize/2
        --   growX=RIGHT → icon[1] is the leftmost icon           → its centre x = iconSize/2
        -- container TOPLEFT.x = frame_centre.x + (baseX + xOffset) - icon1_centre_in_container
        local icon1CentreInContainer = (growX == "LEFT") and (totalW - iconSize / 2) or (iconSize / 2)
        local cxOffset = baseX + xOffset - icon1CentreInContainer

        if growY == "UP" then
            container:SetPoint("BOTTOM", frame, "TOP", cxOffset, pad + yOffset)
        else
            container:SetPoint("TOP", frame, "BOTTOM", cxOffset, -pad + yOffset)
        end
    else
        container:SetPoint("CENTER", UIParent, "CENTER", xOffset, yOffset)
    end

    -- Place icons
    for i = 1, count do
        local aura = auras[i]
        local btn  = GetOrCreateIcon(pool, i, container, prefix)
        btn:SetSize(iconSize, iconSize)
        local col  = (i - 1) % cols
        local row  = math.floor((i - 1) / cols)
        local xStep  = (growX == "RIGHT") and  (iconSize + gap) or -(iconSize + gap)
        local yStep  = (growY == "DOWN")  and -(iconSize + gap) or  (iconSize + gap)
        -- startX/startY: position of icon[1] within the container
        local startX = (growX == "RIGHT") and 0 or (totalW - iconSize)
        local startY = (growY == "DOWN")  and 0 or -(totalH - iconSize)
        btn:ClearAllPoints()
        btn:SetPoint("TOPLEFT", container, "TOPLEFT", startX + col * xStep, startY + row * yStep)

        btn.auraUnit   = unit
        btn.auraIndex  = i
        btn.auraFilter = auraFilter
        btn.icon:SetTexture(aura.icon)
        -- aura.applications and aura.duration can be secret numbers in 12.0 — comparisons must use pcall.
        local showStack = false
        pcall(function() showStack = aura.applications and aura.applications > 1 end)
        btn.stack:SetText(showStack and aura.applications or "")
        SetAuraCooldown(btn.cd, unit, aura)
        -- Custom timer text
        local showTimer  = prefix and db[prefix.."ShowTimer"] ~= false
        local timerFont  = prefix and db[prefix.."TimerFont"]
        local timerSize  = prefix and (db[prefix.."TimerFontSize"] or 10)
        local timerColor = prefix and (db[prefix.."TimerColor"] or {1,1,1,1})
        if showTimer then
            ApplyTimerStyle(btn.timerFS, timerFont, timerSize, timerColor)
            -- Drive the timer text via an OnUpdate on the button.
            btn._auraForTimer = aura
            btn:SetScript("OnUpdate", function(self)
                local a = self._auraForTimer
                if a then self.timerFS:SetText(FormatAuraTimer(a)) end
            end)
            btn.timerFS:Show()
        else
            btn:SetScript("OnUpdate", nil)
            btn.timerFS:SetText("")
            btn.timerFS:Hide()
        end
        local showBorder = false
        pcall(function()
            showBorder = aura.isHarmful and aura.dispelName and DEBUFF_COLORS[aura.dispelName] ~= nil
        end)
        if showBorder then
            local dc = DEBUFF_COLORS[aura.dispelName]
            btn.debuffBorder:SetVertexColor(dc[1], dc[2], dc[3])
            btn.debuffBorder:Show()
        else
            btn.debuffBorder:Hide()
        end
        btn:Show()
    end

    -- Hide unused pool slots; clear timer OnUpdate to avoid stale updates.
    for i = count + 1, #pool do
        pool[i]:SetScript("OnUpdate", nil)
        pool[i]:Hide()
    end
    container:Show()
end

-- ── Aura Bars layout ─────────────────────────────────────────────────────────
-- Each aura is a horizontal status bar with icon + name label + optional timer.
-- The bar frame is a free-floating window anchored to UIParent, position stored
-- in db as barX/barY (offset from screen centre).

local function GetOrCreateBar(pool, idx, container)
    if pool[idx] then return pool[idx] end
    local bar = CreateFrame("StatusBar", nil, container)
    bar:SetStatusBarTexture("Interface\\Buttons\\WHITE8X8")
    bar:SetMinMaxValues(0, 1)
    bar:SetValue(1)

    local icon = bar:CreateTexture(nil, "OVERLAY")
    icon:SetTexCoord(0.08, 0.92, 0.08, 0.92)
    bar.icon = icon

    local name = bar:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
    name:SetJustifyH("LEFT")
    name:SetWordWrap(false)
    bar.name = name

    local timer = bar:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
    timer:SetJustifyH("RIGHT")
    bar.timer = timer

    local cd = CreateFrame("Cooldown", nil, bar, "CooldownFrameTemplate")
    cd:SetDrawEdge(false); cd:SetDrawSwipe(true); cd:SetHideCountdownNumbers(true)
    cd:SetReverse(true)
    bar.cd = cd

    local bg = bar:CreateTexture(nil, "BACKGROUND")
    bg:SetAllPoints()
    bg:SetColorTexture(0, 0, 0, 0.5)
    bar.bg = bg

    pool[idx] = bar
    return bar
end

local function LayoutAuraBars(slot, auras, frame, db, prefix, unit, auraFilter)
    slot.barPool = slot.barPool or {}
    for _, p in ipairs({ slot.iconPool or {}, slot.ringPool or {} }) do
        for i = 1, #p do p[i]:Hide() end
    end
    local container = slot.container
    local pool      = slot.barPool
    local maxShown   = db[prefix.."MaxShown"]  or 8
    local barW       = math.max(40, db[prefix.."BarWidth"]  or 160)
    local barH       = math.max(8,  db[prefix.."BarHeight"] or 18)
    local barX       = db[prefix.."BarX"] or 0
    local barY       = db[prefix.."BarY"] or 0
    local showTimer  = db[prefix.."ShowTimer"] ~= false
    local timerFont  = db[prefix.."TimerFont"]
    local timerSize  = db[prefix.."TimerFontSize"] or 10
    local timerColor = db[prefix.."TimerColor"] or {1, 1, 1, 1}
    local count      = math.min(#auras, maxShown)

    if count == 0 then
        container:Hide()
        for i = 1, #pool do pool[i]:Hide() end
        return
    end

    local iconSz = barH
    local gap    = 2
    local totalH = count * (barH + gap) - gap

    container:SetSize(barW, math.max(1, totalH))
    container:ClearAllPoints()
    container:SetPoint("CENTER", UIParent, "CENTER", barX, barY)

    for i = 1, count do
        local aura = auras[i]
        local bar  = GetOrCreateBar(pool, i, container)
        bar:SetSize(barW, barH)
        bar:ClearAllPoints()
        bar:SetPoint("TOPLEFT", container, "TOPLEFT", 0, -(i - 1) * (barH + gap))

        -- Icon
        bar.icon:SetSize(iconSz, iconSz)
        bar.icon:SetPoint("LEFT", bar, "LEFT", 0, 0)
        bar.icon:SetTexture(aura.icon)

        -- Colour: debuff type colour, else class-ish teal for buffs
        local r, g, b = 0.2, 0.6, 1.0
        pcall(function()
            if aura.isHarmful and aura.dispelName and DEBUFF_COLORS[aura.dispelName] then
                local dc = DEBUFF_COLORS[aura.dispelName]
                r, g, b = dc[1], dc[2], dc[3]
            elseif not aura.isHarmful then
                r, g, b = 0.2, 0.8, 0.4
            end
        end)
        bar:SetStatusBarColor(r, g, b, 0.8)

        -- Duration: apply cooldown sweep + drive fill fraction.
        bar.cd:SetAllPoints(bar)
        bar.cd:SetHideCountdownNumbers(true)
        SetAuraCooldown(bar.cd, unit, aura)

        -- Status bar fill: best-effort; falls back to full on secret-number failure
        bar:SetValue(1)
        pcall(function()
            if aura.duration and aura.duration > 0 then
                local frac = 1 - math.max(0, math.min(1,
                    (aura.duration - (aura.expirationTime - GetTime())) / aura.duration))
                bar:SetValue(frac)
            end
        end)

        -- Name label (between icon and right edge; shrinks when timer is shown)
        local textX = iconSz + 3
        bar.name:ClearAllPoints()
        bar.name:SetPoint("LEFT",  bar, "LEFT",  textX, 0)
        bar.name:SetPoint("RIGHT", bar, "RIGHT", showTimer and -38 or -3, 0)
        bar.name:SetText(aura.name or "")

        -- Custom timer text on the right side of the bar
        if showTimer then
            ApplyTimerStyle(bar.timer, timerFont, timerSize, timerColor)
            bar.timer:ClearAllPoints()
            bar.timer:SetPoint("RIGHT", bar, "RIGHT", -3, 0)
            bar._auraForTimer = aura
            bar:SetScript("OnUpdate", function(self)
                local a = self._auraForTimer
                if a then self.timer:SetText(FormatAuraTimer(a)) end
            end)
            bar.timer:Show()
        else
            bar:SetScript("OnUpdate", nil)
            bar.timer:SetText("")
            bar.timer:Hide()
        end

        bar:Show()
    end

    for i = count + 1, #pool do
        pool[i]:SetScript("OnUpdate", nil)
        pool[i]:Hide()
    end
    container:Show()
end

-- ── Aura Rings layout ────────────────────────────────────────────────────────
-- Each aura is a donut ring centred on the unit orb.  Rings grow outward
-- from startRadius, each ring gap apart.  Colour indicates dispel type / buff.

local function GetOrCreateRing(pool, idx, container)
    if pool[idx] then return pool[idx] end
    local f = CreateFrame("Frame", nil, container)

    -- Single donut texture with a real alpha-channel hole — background shows through.
    local tex = f:CreateTexture(nil, "BACKGROUND")
    tex:SetAllPoints()
    tex:SetTexture(RING_TEXTURES[2][2])  -- default; updated each layout pass
    tex:SetBlendMode("BLEND")
    f.tex = tex

    -- Cooldown sweep (clock wipe showing remaining duration)
    local cd = CreateFrame("Cooldown", nil, f, "CooldownFrameTemplate")
    cd:SetAllPoints(); cd:SetDrawEdge(false); cd:SetDrawSwipe(true)
    cd:SetHideCountdownNumbers(true)
    cd:SetReverse(true)
    f.cd = cd

    -- Stack count label at top-right of the ring frame
    local stack = f:CreateFontString(nil, "OVERLAY", "NumberFontNormal")
    stack:SetPoint("TOPRIGHT", f, "TOPRIGHT", 0, 0)
    f.stack = stack

    -- Custom timer text shown at the bottom-centre of the ring
    local timerFS = f:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
    timerFS:SetPoint("BOTTOM", f, "BOTTOM", 0, 2)
    timerFS:SetJustifyH("CENTER")
    timerFS:SetText("")
    f.timerFS = timerFS

    pool[idx] = f
    return f
end

local function LayoutAuraRings(slot, auras, frame, db, prefix, unit, auraFilter)
    slot.ringPool = slot.ringPool or {}
    for _, p in ipairs({ slot.iconPool or {}, slot.barPool or {} }) do
        for i = 1, #p do p[i]:Hide() end
    end
    local container = slot.container
    local pool      = slot.ringPool
    local maxShown   = db[prefix.."MaxShown"]  or 8
    local startR     = math.max(10, db[prefix.."RingRadius"] or 60)
    local gap        = math.max(2,  db[prefix.."RingGap"]    or 8)
    local showTimer  = db[prefix.."ShowTimer"] ~= false
    local timerFont  = db[prefix.."TimerFont"]
    local timerSize  = db[prefix.."TimerFontSize"] or 10
    local timerColor = db[prefix.."TimerColor"] or {1, 1, 1, 1}
    local count      = math.min(#auras, maxShown)

    if count == 0 then
        container:Hide()
        for i = 1, #pool do pool[i]:Hide() end
        return
    end

    -- Container is a 1×1 point anchored to the orb centre; each ring is a
    -- child centred on this point, growing outward.
    container:SetSize(1, 1)
    container:ClearAllPoints()
    if frame then
        container:SetPoint("CENTER", frame, "CENTER", 0, 0)
    else
        container:SetPoint("CENTER", UIParent, "CENTER", 0, 0)
    end

    for i = 1, count do
        local aura = auras[i]
        local ring = GetOrCreateRing(pool, i, container)

        -- Each ring's outer diameter grows by gap per step
        local outerR  = startR + (i - 1) * gap
        local sz      = outerR * 2

        ring:SetSize(sz, sz)
        ring:ClearAllPoints()
        ring:SetPoint("CENTER", container, "CENTER", 0, 0)

        -- Pick the donut texture whose band scales closest to RING_BAND_PX
        ring.tex:SetTexture(ChooseRingTexture(sz))

        -- Colour by dispel type or buff
        local cr, cg, cb, ca = 0.2, 0.8, 0.4, 0.75
        pcall(function()
            if aura.isHarmful then
                if aura.dispelName and DEBUFF_COLORS[aura.dispelName] then
                    local dc = DEBUFF_COLORS[aura.dispelName]
                    cr, cg, cb = dc[1], dc[2], dc[3]
                else
                    cr, cg, cb = 1, 0.2, 0.2
                end
                ca = 0.7
            end
        end)
        ring.tex:SetVertexColor(cr, cg, cb, ca)

        -- Stack count
        local showStack = false
        pcall(function() showStack = aura.applications and aura.applications > 1 end)
        ring.stack:SetText(showStack and aura.applications or "")

        SetAuraCooldown(ring.cd, unit, aura)

        -- Custom timer text
        if showTimer then
            ApplyTimerStyle(ring.timerFS, timerFont, timerSize, timerColor)
            ring._auraForTimer = aura
            ring:SetScript("OnUpdate", function(self)
                local a = self._auraForTimer
                if a then self.timerFS:SetText(FormatAuraTimer(a)) end
            end)
            ring.timerFS:Show()
        else
            ring:SetScript("OnUpdate", nil)
            ring.timerFS:SetText("")
            ring.timerFS:Hide()
        end

        ring:Show()
    end

    for i = count + 1, #pool do
        pool[i]:SetScript("OnUpdate", nil)
        pool[i]:Hide()
    end
    container:Show()
end

-- ── Test Aura Mode ───────────────────────────────────────────────────────────
-- Generates fake AuraData-like tables so the user can preview aura layouts
-- without needing live buffs/debuffs active.
-- 10 entries each for buffs and debuffs; durations stagger 60s→10s in 5s steps.

local testAurasActive = false

local TEST_ICONS_BUFF = {
    136096, 136108, 136116, 135932, 136048,
    132242, 135946, 135887, 136051, 135967,
}
local TEST_ICONS_DEBUFF = {
    136139, 136107, 132114, 135829, 135902,
    136183, 135818, 136154, 132336, 135991,
}
local TEST_DISPEL = { nil, nil, nil, "Magic", "Poison", nil, "Curse", nil, "Disease", nil }

local function MakeTestAuras(isHarmful)
    local icons   = isHarmful and TEST_ICONS_DEBUFF or TEST_ICONS_BUFF
    local auras   = {}
    local now     = GetTime()
    for i = 1, 10 do
        local dur = 65 - i * 5   -- 60, 55, 50 … 10
        auras[i] = {
            auraInstanceID          = 900000 + i + (isHarmful and 100 or 0),
            spellId                 = 900000 + i,
            name                    = isHarmful and ("Debuff "..i) or ("Buff "..i),
            icon                    = icons[i],
            applications            = (i == 3) and 3 or 0,
            duration                = dur,
            expirationTime          = now + dur,
            isHelpful               = not isHarmful,
            isHarmful               = isHarmful,
            isFromPlayerOrPlayerPet = true,
            dispelName              = isHarmful and TEST_DISPEL[i] or nil,
            timeMod                 = 1,
            charges                 = 0,
        }
    end
    return auras
end

function UnitFramesLite_SetTestAuras(enable)
    testAurasActive = enable
    for u in pairs(frames) do
        UnitFramesLite_UpdateAuras(u)
    end
end

function UnitFramesLite_SetTestResource(enable)
    testResourceActive = enable
    UnitFramesLite_UpdateResourceVisibility()
    if UpdateResourcePips then UpdateResourcePips() end
end
function UnitFramesLite_IsTestResourceActive()
    return testResourceActive
end

function UnitFramesLite_UpdateAuras(unit)
    local data = GetAuraData(unit)

    local frame = frames[unit]
    if not frame or not frame:IsShown() then
        data.buff.container:Hide()
        data.debuff.container:Hide()
        return
    end

    local db = GetDB(unit)

    -- Test aura mode: inject fake auras for visual preview
    if testAurasActive then
        local testBuffs   = (db.buffShowBuffs   ~= false) and MakeTestAuras(false) or {}
        local testDebuffs = (db.debuffShowDebuffs ~= false) and MakeTestAuras(true)  or {}
        local function layoutSlotTest(slot, auras, showKey, prefix, defaultGrowX, defaultGrowY, filter)
            if db[showKey] == false or #auras == 0 then
                slot.container:Hide()
                HideAllPools(slot)
                return
            end
            local mode = db[prefix.."DisplayMode"] or "Icons"
            if mode == "Bars" then
                LayoutAuraBars(slot, auras, frame, db, prefix, unit, filter)
            elseif mode == "Rings" then
                LayoutAuraRings(slot, auras, frame, db, prefix, unit, filter)
            else
                LayoutAuraStrip(slot, auras, frame, db,
                    db[prefix.."IconSize"]  or 24,
                    db[prefix.."PerRow"]    or 4,
                    db[prefix.."MaxShown"]  or 8,
                    db[prefix.."GrowX"]     or defaultGrowX,
                    db[prefix.."GrowY"]     or defaultGrowY,
                    db[prefix.."XOffset"]   or 0,
                    db[prefix.."YOffset"]   or 0,
                    db[prefix.."AnchorToFrame"] ~= false,
                    0, unit, filter, prefix)
            end
        end
        layoutSlotTest(data.buff,   testBuffs,   "buffShowBuffs",    "buff",   "RIGHT", "DOWN", "HELPFUL")
        layoutSlotTest(data.debuff, testDebuffs, "debuffShowDebuffs", "debuff", "LEFT",  "UP",   "HARMFUL")
        return
    end

    -- Collect buffs
    local buffs = {}
    if db.buffShowBuffs ~= false and C_UnitAuras and C_UnitAuras.GetAuraDataByIndex then
        local threshold    = db.buffHideOverDuration or 0
        local applyFilter  = threshold > 0 and UnitIsFriend("player", unit)
        local i = 1
        while true do
            local aura = C_UnitAuras.GetAuraDataByIndex(unit, i, "HELPFUL")
            if not aura then break end
            if applyFilter then
                -- aura.duration is a plain number on friendly units (not secret).
                -- duration == 0 means permanent — exclude. duration > threshold — exclude.
                local include = false
                pcall(function()
                    include = aura.duration > 0 and aura.duration <= threshold
                end)
                if include then buffs[#buffs + 1] = aura end
            else
                buffs[#buffs + 1] = aura
            end
            i = i + 1
        end
    end

    -- Collect debuffs
    local debuffs = {}
    if db.debuffShowDebuffs ~= false and C_UnitAuras and C_UnitAuras.GetAuraDataByIndex then
        local threshold   = db.debuffHideOverDuration or 0
        local applyFilter = threshold > 0 and UnitIsFriend("player", unit)
        local i = 1
        while true do
            local aura = C_UnitAuras.GetAuraDataByIndex(unit, i, "HARMFUL")
            if not aura then break end
            local fromPlayer = false
            pcall(function() fromPlayer = aura.isFromPlayerOrPlayerPet == true end)
            if db.debuffPlayerOnly and not fromPlayer then
                -- skip
            elseif db.debuffCurableOnly and not (aura.dispelName and DISPEL_TYPES[aura.dispelName]) then
                -- skip
            elseif applyFilter then
                -- Only filter by duration on friendly units (duration is a plain number there).
                -- duration == 0 means permanent — exclude. duration > threshold — exclude.
                local include = false
                pcall(function()
                    include = aura.duration > 0 and aura.duration <= threshold
                end)
                if include then debuffs[#debuffs + 1] = aura end
            else
                debuffs[#debuffs + 1] = aura
            end
            i = i + 1
        end
    end

    local function layoutSlot(slot, auras, showKey, prefix, defaultGrowX, defaultGrowY, filter)
        if db[showKey] == false or #auras == 0 then
            slot.container:Hide()
            HideAllPools(slot)
            return
        end
        local mode = db[prefix.."DisplayMode"] or "Icons"
        if mode == "Bars" then
            LayoutAuraBars(slot, auras, frame, db, prefix, unit, filter)
        elseif mode == "Rings" then
            LayoutAuraRings(slot, auras, frame, db, prefix, unit, filter)
        else  -- "Icons"
            LayoutAuraStrip(slot, auras, frame, db,
                db[prefix.."IconSize"]  or 24,
                db[prefix.."PerRow"]    or 4,
                db[prefix.."MaxShown"]  or 8,
                db[prefix.."GrowX"]     or defaultGrowX,
                db[prefix.."GrowY"]     or defaultGrowY,
                db[prefix.."XOffset"]   or 0,
                db[prefix.."YOffset"]   or 0,
                db[prefix.."AnchorToFrame"] ~= false,
                0, unit, filter, prefix)
        end
    end

    layoutSlot(data.buff,   buffs,   "buffShowBuffs",   "buff",   "RIGHT", "DOWN", "HELPFUL")
    layoutSlot(data.debuff, debuffs, "debuffShowDebuffs","debuff", "LEFT",  "UP",   "HARMFUL")
end

function UnitFramesLite_UpdateAllAuras()
    for unit in pairs(frames) do
        UnitFramesLite_UpdateAuras(unit)
    end
end

function UnitFramesLite_PositionAuraFrame(unit)
    -- Called after the unit frame moves/resizes so auras re-anchor correctly
    UnitFramesLite_UpdateAuras(unit)
end

-- Addon lifecycle ------------------------------------------------------------

local eventFrame = CreateFrame("Frame")
eventFrame:RegisterEvent("ADDON_LOADED")
eventFrame:RegisterEvent("PLAYER_LOGIN")
eventFrame:RegisterEvent("PLAYER_REGEN_ENABLED")
eventFrame:RegisterEvent("PLAYER_REGEN_DISABLED")
eventFrame:RegisterEvent("PLAYER_FLAGS_CHANGED")
eventFrame:RegisterEvent("UPDATE_STEALTH")
eventFrame:RegisterEvent("GROUP_ROSTER_UPDATE")
eventFrame:RegisterEvent("ZONE_CHANGED_NEW_AREA")
eventFrame:RegisterEvent("PLAYER_ENTERING_WORLD")
eventFrame:RegisterEvent("PLAYER_TARGET_CHANGED")
eventFrame:RegisterEvent("PLAYER_FOCUS_CHANGED")
eventFrame:RegisterEvent("UNIT_PET")
eventFrame:RegisterUnitEvent("UNIT_POWER_FREQUENT", "player")
eventFrame:RegisterUnitEvent("UNIT_MAXPOWER", "player")
eventFrame:RegisterUnitEvent("UNIT_DISPLAYPOWER", "player")
eventFrame:RegisterEvent("PLAYER_SPECIALIZATION_CHANGED")
eventFrame:RegisterEvent("UPDATE_SHAPESHIFT_FORM")
eventFrame:RegisterUnitEvent("UNIT_AURA", "player")
eventFrame:RegisterUnitEvent("UNIT_AURA", "target")
eventFrame:RegisterUnitEvent("UNIT_AURA", "focus")
eventFrame:RegisterUnitEvent("UNIT_AURA", "pet")
eventFrame:SetScript("OnEvent", function(self, event, arg1)
    if event == "ADDON_LOADED" and arg1 == addonName then
        UnitFramesLiteDB = UnitFramesLiteDB or {}
        -- Global (non-unit) settings
        UnitFramesLiteDB.global = UnitFramesLiteDB.global or {
            hideBlizzPlayer    = false,
            hideBlizzTarget    = false,
            hideBlizzTargetToT = false,
            hideBlizzFocus     = false,
            hideBlizzFocusToT  = false,
            hideBlizzPet       = false,
            hideBlizzPetTarget = false,
            showMinimapButton  = true,
            showBazookaPlugin  = true,
        }
        -- Migrate: ensure new global keys exist for older SavedVariables
        local g = UnitFramesLiteDB.global
        if g.showMinimapButton  == nil then g.showMinimapButton  = true  end
        if g.showBazookaPlugin  == nil then g.showBazookaPlugin  = true  end
        if g.hideBlizzTargetToT == nil then g.hideBlizzTargetToT = false end
        if g.hideBlizzFocusToT  == nil then g.hideBlizzFocusToT  = false end
        if g.hideBlizzPetTarget == nil then g.hideBlizzPetTarget = false end
        -- Profiles table: { active="Default", profiles={ Default={player={...}, target={...}, ...} } }
        UnitFramesLiteDB.profiles = UnitFramesLiteDB.profiles or { active = "Default", list = {} }
        -- Migrate: showOrbPower (bool) → orbPowerMode (string)
        -- Migrate: showPowerBar (bool) → orbPowerMode (string)
        -- Runs before CopyDefaults. Also fixes saves where orbPowerMode was wrongly
        -- set to "None" by a previous version that had it in defaults.
        for _, unit in ipairs({"player", "target", "focus", "pet"}) do
            local udb = UnitFramesLiteDB[unit]
            if udb then
                if udb.showOrbPower == true and (udb.orbPowerMode == nil or udb.orbPowerMode == "None") then
                    udb.orbPowerMode = "Ring"
                elseif udb.showPowerBar == true and udb.orbPowerMode == nil then
                    udb.orbPowerMode = "Bar"
                end
            end
        end
        for unit, def in pairs(defaults) do
            UnitFramesLiteDB[unit] = CopyDefaults(def, UnitFramesLiteDB[unit] or {})
        end
        -- Migrate: buffYOffset was previously defaulted to 0; new default is -15
        for _, unit in ipairs({"player", "target"}) do
            local udb = UnitFramesLiteDB[unit]
            if udb and udb.buffYOffset == 0 then udb.buffYOffset = -15 end
        end
        -- Migrate: target buff/debuff X offset was previously 0; new default is 45
        local tudb = UnitFramesLiteDB["target"]
        if tudb then
            if tudb.buffXOffset  == 0 then tudb.buffXOffset  = 45 end
            if tudb.debuffXOffset == 0 then tudb.debuffXOffset = 45 end
        end
        local ok, err = pcall(CreateOptionsPanel)
        if not ok then
            print("|cffff4444UnitFramesLite|r: options panel error: " .. tostring(err))
        end
    elseif event == "PLAYER_LOGIN" then
        -- Rebuild power type colour lookup from SavedVariables (DB now loaded)
        UnitFramesLite_RebuildPowerColors()
        -- Player and Target are declared in XML; Focus and Pet are dynamic
        local focusFrame = CreateUFLDisplayFrame("UFL_FocusFrame", 0,    -220)
        local petFrame   = CreateUFLDisplayFrame("UFL_PetFrame",   -220, -240)
        SetupFrame(UFL_PlayerFrame, "player")
        SetupFrame(UFL_TargetFrame, "target")
        SetupFrame(focusFrame,      "focus")
        SetupFrame(petFrame,        "pet")
        for unit in pairs(defaults) do
            UnitFramesLite_UpdateFrame(unit)
        end
        UnitFramesLite_ApplyBlizzardFrames()
        UFL.ApplyMinimapButton()
        UFL.ApplyBazookaPlugin()
        SetupResourcePips()
        RegisterResourceOnUpdate(eventFrame)
        UnitFramesLite_UpdateResourceVisibility()
        -- Register Masque groups eagerly so UnitFramesLite appears in Masque's
        -- addon list even before any aura icons have been created.
        GetMSQGroup("buff")
        GetMSQGroup("debuff")
        -- Initialise aura containers for all units
        for unit in pairs(defaults) do GetAuraContainer(unit) end
        UnitFramesLite_UpdateAllAuras()
        for unit in pairs(defaults) do UnitFramesLite_UpdateAlpha(unit) end
    elseif event == "UNIT_AURA" then
        UnitFramesLite_UpdateAuras(arg1)
    elseif event == "PLAYER_TARGET_CHANGED" then
        UnitFramesLite_UpdateVisibility("target")
        UnitFramesLite_UpdateFrame("target")
        UnitFramesLite_UpdateAlpha("player")
        UnitFramesLite_UpdateAlpha("target")
        UnitFramesLite_UpdateResourceVisibility()
        -- Clear target auras immediately so stale icons from the previous target
        -- don't flash before UNIT_AURA fires with the new target's data.
        local td = auraFrames["target"]
        if td then
            td.buff.container:Hide()
            td.debuff.container:Hide()
            HideAllPools(td.buff)
            HideAllPools(td.debuff)
        end
        UnitFramesLite_UpdateAuras("target")
    elseif event == "PLAYER_FOCUS_CHANGED" then
        UnitFramesLite_UpdateVisibility("focus")
        UnitFramesLite_UpdateFrame("focus")
        UnitFramesLite_UpdateAlpha("focus")
        UnitFramesLite_UpdateAuras("focus")
    elseif event == "UNIT_PET" then
        UnitFramesLite_UpdateVisibility("pet")
        UnitFramesLite_UpdateAlpha("pet")
    elseif event == "UNIT_POWER_FREQUENT" or event == "UNIT_MAXPOWER" then
        UpdateResourcePips()
    elseif event == "UNIT_DISPLAYPOWER" then
        -- Fires when the player's primary power type changes (e.g. Druid shifting forms).
        -- catFormOnly resources (Druid combo points) should appear/disappear accordingly.
        -- UpdateFrame also reapplies the orb power bar colour (orbPowerBarUseTypeColor)
        -- which is only set during UpdateFrame, not in the per-frame Update() closure.
        UnitFramesLite_UpdateFrame("player")
        SetupResourcePips()
        UnitFramesLite_UpdateResourceLayout()
        UpdateResourcePips()
        UnitFramesLite_UpdateResourceVisibility()
    elseif event == "PLAYER_SPECIALIZATION_CHANGED" or event == "UPDATE_SHAPESHIFT_FORM" then
        SetupResourcePips()
        UnitFramesLite_UpdateResourceLayout()
        UpdateResourcePips()
        UnitFramesLite_UpdateResourceVisibility()
    elseif event == "PLAYER_REGEN_ENABLED" or event == "PLAYER_REGEN_DISABLED" then
        for unit in pairs(frames) do
            UnitFramesLite_UpdateAlpha(unit)
            UnitFramesLite_UpdateVisibility(unit)
        end
        UnitFramesLite_UpdateResourceVisibility()
    else
        for unit in pairs(frames) do UnitFramesLite_UpdateVisibility(unit) end
        UnitFramesLite_UpdateAllAuras()
    end
end)

local vehicleFrame = CreateFrame("Frame")
vehicleFrame:RegisterUnitEvent("UNIT_ENTERED_VEHICLE", "player")
vehicleFrame:RegisterUnitEvent("UNIT_EXITED_VEHICLE",  "player")
vehicleFrame:SetScript("OnEvent", function()
    for unit in pairs(frames) do UnitFramesLite_UpdateVisibility(unit) end
end)
